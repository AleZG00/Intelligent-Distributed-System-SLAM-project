function [Bpos, P] = useDroneCPos(d, Bpos, dronePos, sigma_radar, P, neighbors,viewRadius)
% useDroneCPos
% Covariance Intersection method to allow the drones to use with
% intermitent connections their relative pose
% Inputs:
%   d              - drone that measures
%   Bpos           - [3 x 2] believed positions of all drones
%   dronePos       - [3 x 2] true positions (for simulating measurement)
%   sigma_radar    - vector [σ1 σ2 σ3] of measurement std deviations
%   P              - [6 x 6] covariance matrix of all drone states
%   neighbors      - Matrix with drones connections
%   viewRadius     - Max visibility range to scale down error
%                    proportionally
%
% Output:
%   Bpos           - updated believed positions
%   P              - updated covariance

    xreal = dronePos(d,1); yreal = dronePos(d,2);
    px_hat = Bpos(d,1);  py_hat = Bpos(d,2);

    for i = 1:length(neighbors{d})
        neig = neighbors{d}(i);
        xreal2 = dronePos(neig,1); yreal2 = dronePos(neig,2);
        z_true = sqrt((xreal - xreal2)^2 + (yreal - yreal2)^2); 
        zBelive = sqrt((Bpos(neig,1) - px_hat)^2 + (Bpos(neig,2) - py_hat)^2); 
        
        dx = Bpos(neig,1) - px_hat;
        dy = Bpos(neig,2) - py_hat;
        H_lin = [-dx/zBelive,  -dy/zBelive; dx/zBelive, dy/zBelive]; 
        zr = z_true + z_true/viewRadius*sigma_radar(d)*randn;

        idx_x = d*2 - 1;             % index of drone's x in x_model
        idx_y = d*2;                 % index of drone's y in x_model
        idx_x2 = neig*2 - 1;             % index of drone's x in x_model
        idx_y2 = neig*2;                 % index of drone's y in x_model
    
        % Measurement noise scaled on measuring distance
        Rd = z_true/viewRadius*sigma_radar(d)^2 * eye(2);  % noise from drone d's radar (2D)
       
        % Pose estimation of reciever drone from donor
        xj = px_hat + zr*cos(atan2((yreal2 - yreal),(xreal2 - xreal)));
        yj = py_hat + zr*sin(atan2((yreal2 - yreal),(xreal2 - xreal)));

        
        % Covariance calculation from donor drone
        Pj_from_i = H_lin*P(idx_x:idx_y, idx_x:idx_y)*H_lin' + Rd;
        % Actual Covariance of reciever drone
        Pj = P(idx_x2:idx_y2, idx_x2:idx_y2);

        % omega calculation trough trace minimization
        w = fminbnd(@(w) trace(inv(w*inv(Pj) + (1-w)*inv(Pj_from_i))), 0, 1);
        % Calculation of the otimum Covariance matrix for the reciever
        % drone
        Pj_opt = inv(w*inv(Pj) + (1-w)*inv(Pj_from_i));
        xyj = Pj_opt * (w *inv(Pj)*Bpos(neig,:)' + (1-w)*inv(Pj_from_i)*[xj;yj]);

        P(idx_x2:idx_y2, idx_x2:idx_y2) = Pj_opt;
        Bpos(neig,:) = xyj;
    end


end
