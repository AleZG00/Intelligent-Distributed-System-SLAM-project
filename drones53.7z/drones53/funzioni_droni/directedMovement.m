function direction = directedMovement(Pos, target)

    v = target - Pos;                 % displacement vector
    direction = v / norm(v);          % normalize to unit length

end
