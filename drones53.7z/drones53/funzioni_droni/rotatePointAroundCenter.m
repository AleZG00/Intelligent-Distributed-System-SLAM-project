function p_rot = rotatePointAroundCenter(p, center, angle_deg)
    % rotatePointAroundCenter - rotates a point around a given center
    %
    % INPUTS:
    %   p          = [row, col]  point to rotate
    %   center     = [row, col]  rotation center
    %   angle_deg  = rotation angle in degrees (CCW positive)
    %
    % OUTPUT:
    %   p_rot      = [row, col] rotated point (rounded to integer)
    %
    % Conventions:
    %   - positive rotation is counterclockwise

    % Rotation matrix taking into account rows are y components and columns
    % x components
    theta = deg2rad(angle_deg);
    R = [-sin(theta), cos(theta);
         cos(theta),  sin(theta)];

    % Convert to Cartesian convention (x=col, y=row)
    p_shift = p - center;

    % Rotate and return to matrix convention
    p_xy = R * p_shift' + center;
    p_rot = [p_xy(2), p_xy(1)];

    % Round to integer pixel coordinates
    p_rot = round(p_rot);
end
