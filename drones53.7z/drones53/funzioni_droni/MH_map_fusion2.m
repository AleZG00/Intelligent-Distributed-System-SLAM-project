function [stateMap, uncertainty_Map,localIdMap] = MH_map_fusion2(d,neighbors, stateMap, uncertainty_Map, sigma_velocity, sigma_radar, P0, localIdMap, ~)
% MH_map_fusion2: Efficient Metropolis–Hastings map fusion with uncertainty weighting
% Fusion chooses best sender per-pixel

D = size(stateMap,1);         % number of drones

% Early exit if no drones connected
if all(cellfun(@isempty, neighbors(d)))
    return;
end

% --- Precompute confidence weights ---
joint_sigma = (sigma_velocity / 2 + sigma_radar /2);   % 1 x D
joint_variance = joint_sigma.^2;
conf = 1 ./ joint_variance;

% --- Build weight matrix (W) ---
W = zeros(D);
if joint_sigma(1) ~= joint_sigma(2) || joint_sigma(1) ~= joint_sigma(3)
    for i = 1:D
        % if isempty(neighbors{i}), continue; end
        neigh_i = [neighbors{i}(:)', i]; % row vector of neighbor indices plus self
        denom = sum(conf(neigh_i));
        if denom == 0, continue; end
        W(i,neigh_i) = conf(neigh_i) / denom;
    end
else
    for i = 1:D
        for j = 1:D
            if i~=j && any(i == neighbors{j}(:))
                W(i,j) = 1/(max(length(neighbors{j}(:)'),length(neighbors{i}(:)'))+1);
            end
        end
        W(i,i) = 1 - sum(W(i,:));
    end
end

neigh_i = [neighbors{d}(:)', d];
% --- Identify "seen" pixels for all drones ---
% seenMask: D x Ny x Nx  (use row-major Ny x Nx)

seenMask = uncertainty_Map < P0;   % logical array same shape as uncertainty_Map
seenMaskC = uncertainty_Map(neigh_i,:,:) < P0;   % logical array same shape as uncertainty_Map
% --- Step 1: Consensus for pixels seen by drones neigh_i ---
commonMask = squeeze(all(seenMaskC, 1));  % check wat is common in seenMask between the neigh_i

if any(commonMask(:)) 
    for i = 1:D 
        if isempty(neighbors{i}), continue; end 
        neigh_i = [neighbors{i}, i]; 
        % Extract only the neighbors that saw each pixel 
        seenNeigh = seenMask(neigh_i,:,:); 
        validMask = squeeze(any(seenNeigh,1)) & commonMask; % N x N logical mask 
        onlyiSeen = commonMask & squeeze(seenMask(i,:,:));
        if ~any(validMask(:)), continue; end % Weighted sum only over visible neighbors 
        weights = W(i,neigh_i); 
        weights = weights / sum(weights); 
        
        % Combine maps for visible pixels (vectorized over neighbors) 
        stateMap(i,onlyiSeen) =  weights * stateMap(neigh_i,onlyiSeen); 
        uncertainty_Map(i,onlyiSeen) = weights * uncertainty_Map(neigh_i,onlyiSeen); 
    end 
end

% --- Step 2: Sharing unseen pixels ---
% someSeenMask: pixels seen by at least one drone (Ny x Nx)
someSeenMask = squeeze(sum(seenMask,1)) > 0;

if any(someSeenMask(:))
    for i = 1:D
        if isempty(neighbors{i}), continue; end

        % unseen by i but seen by SOME neighbor
        unseenByI = ~squeeze(seenMask(i,:,:)) & someSeenMask; % Ny x Nx
        if ~any(unseenByI(:)), continue; end

        neighs = neighbors{i}(:)';             % 1 x nNeigh
        nNeigh = numel(neighs);

        % Build a matrix seen_by_neigh: nNeigh x nPix (logical) for only pixels of interest
        idxPixels = find(unseenByI);          % linear indices of candidate pixels
        nPix = numel(idxPixels);
        seen_by_neigh = false(nNeigh, nPix);
        for k = 1:nNeigh
            sliceSeen = squeeze(seenMask(neighs(k),:,:)); % Ny x Nx
            seen_by_neigh(k,:) = sliceSeen(idxPixels)';
        end

        % For each pixel, pick the neighbor with max conf among those who saw it
        conf_neigh = conf(neighs); % 1 x nNeigh
        % Make matrix conf_masked: nNeigh x nPix where entries are conf if neighbor saw it, else -Inf
        conf_masked = -Inf(nNeigh, nPix);
        for k = 1:nNeigh
            mask_k = seen_by_neigh(k,:);
            conf_masked(k,mask_k) = conf_neigh(k);
        end

        % Find best sender per pixel
        [bestConf, bestIdxPerPixel] = max(conf_masked, [], 1); % bestIdxPerPixel in 1..nNeigh, bestConf -Inf means nobody saw
        validPixels = bestConf > -Inf;
        if ~any(validPixels), continue; end

        pixLinear = idxPixels(validPixels);
        bestIdxs = bestIdxPerPixel(validPixels); % indices into neighs

        % Now assign from the chosen best neighbor for each pixel
        tmpState = squeeze(stateMap(i,:,:));
        tmpUnc   = squeeze(uncertainty_Map(i,:,:));

        for p = 1:numel(pixLinear)
            pix = pixLinear(p);
            bestNeighborIdx = neighs(bestIdxs(p));  % actual drone index
            tmpState(pix) = stateMap(bestNeighborIdx, pix);
            tmpUnc(pix)   = uncertainty_Map(bestNeighborIdx, pix);
        end

        stateMap(i,:,:) = tmpState;
        uncertainty_Map(i,:,:) = tmpUnc;
    end

    % Share of the ID's map
    neigh_i = neighbors{d}; 
    for j = 1:length(neigh_i)
        i = neigh_i(j);
        if i~=d
            if i + d == 3 
                localIdMap(d,:,:) = max(squeeze(localIdMap(d,:,:)),squeeze(localIdMap(i,:,:)));
            end
            if i + d == 5
                localIdMap(d,:,:) = max(squeeze(localIdMap(d,:,:)),squeeze(localIdMap(i,:,:)));
            end
            if i + d == 4
                localIdMap(d,:,:) = max(squeeze(localIdMap(d,:,:)),squeeze(localIdMap(i,:,:)));

            end
        end
    end

end

end
