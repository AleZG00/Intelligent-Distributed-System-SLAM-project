function bestMove = chooseExplorationMove( pos, N, radius,~,Pmove)
    dir = [1,0; -1,0; 0,1; 0,-1; 1,1; -1,1; 1,-1; -1,-1]; % 8 compass directions   
    Pmove2=[Pmove(1),Pmove(2)];

    while true
        
        if pos(1) > 50 && pos(1) < N-50 && pos(2) > 50 && pos(2) < N-50
            bestMove = Pmove2;
        return;
        end
        pdir = dir(round(rand(1)*7+1),:);
        candidatePos = round(pos + pdir * radius); % Predict move
        
        x = candidatePos(1);
        y = candidatePos(2);
        
        % check if with the new direction the robot will go in a direction
        % where it has already seen all the map
        if x > 1 && x < N && y > 1 && y < N && ~isequal(pdir, -Pmove2)            
           pdir1 = [pdir(1)/norm(pdir), pdir(2)/norm(pdir)];
           bestMove = pdir1;
        return;
        end
    end    
        
end
