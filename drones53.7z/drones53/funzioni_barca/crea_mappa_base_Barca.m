function [typeMap_Barca, idMap_Barca, nextID] = crea_mappa_base_Barca()
    % Create base map with cliff, reefs, barriers and buoys
    
    N = 1000; % map size (N×N)
    typeMap_Barca = zeros(N,N); % 0=water, 1=cliff,2=barrier,3=buoy,4=reef
    idMap_Barca = zeros(N,N); % per-cell obstacle ID (0 = unlabeled)
    nextID = uint16(1);

    % 1) CLIFF
    coastY = 100*randn(1,N)+10;
    coastY = round( smoothdata(coastY,'gaussian',100) );
    coastY = min(max(coastY,1),N);
    [Ygrid,~] = meshgrid(1:N,1:N);  
    cliffMask = (Ygrid <= repmat(coastY',1,N)) & (typeMap_Barca==0);
    typeMap_Barca(cliffMask) = 1;
    idMap_Barca(cliffMask) = nextID;
    nextID = nextID + 1;

    % 2) REEFS 
    numReefs = 50;
    reefSeeds = [];
    minDist = 20;
    for k = 1:numReefs
        while true
            cx = randi([50, N]); cy = randi([1, N]);
            if typeMap_Barca(cx,cy)==0, break; end
        end
        if ~isempty(reefSeeds)
            dists = hypot(reefSeeds(:,1)-cx, reefSeeds(:,2)-cy);
            if any(dists < minDist), continue; end
        end
        reefSeeds(end+1,:) = [cx,cy];
        
        reefMask = false(N);
        frontier = sub2ind([N, N], cx, cy);
        reefMask(frontier) = true;

        while nnz(reefMask) < 80 && ~isempty(frontier)
            [fx, fy] = ind2sub([N, N], frontier);
            newFrontier = [];
            for i = 1:numel(frontier)
                neighbors = [fx(i)-1, fy(i); fx(i)+1, fy(i); fx(i), fy(i)-1; fx(i), fy(i)+1];
                for j = 1:4
                    nx = neighbors(j,1);
                    ny = neighbors(j,2);
                    if nx >= 1 && nx <= N && ny >= 1 && ny <= N
                        idx = sub2ind([N,N], nx, ny);
                        if typeMap_Barca(idx) == 0 && ~reefMask(idx)
                            reefMask(idx) = true;
                            newFrontier(end+1) = idx;
                            if nnz(reefMask) >= 80, break; end
                        end
                    end
                end
                if nnz(reefMask) >= 80, break; end
            end
            frontier = newFrontier;
        end

        typeMap_Barca(reefMask) = 4;
        idMap_Barca(reefMask) = nextID;
        nextID = nextID + 1;
    end

    % 3) BARRIERS 
    numBarriers = 100;
    for k = 1:numBarriers
        cx = randi([100, N-100]);
        cy = randi([0, N]);
        r = randi([5, 15]);
        [X,Y] = meshgrid(1:N,1:N);
        mask = (X - cx).^2 + (Y - cy).^2 <= r^2;
        mask = mask & (typeMap_Barca==0);
        if nnz(mask)<5, continue; end
        typeMap_Barca(mask) = 2;
        idMap_Barca(mask) = nextID;
        nextID = nextID + 1;
    end

    % 4) BUOYS 
    numBuoys = 15;
    for k = 1:numBuoys
        while true
            cx = randi([1, N]); cy = randi([1, N]);
            if typeMap_Barca(cx,cy)==0, break; end
        end
        rr = randi([2,5]);
        [X,Y] = meshgrid(1:N,1:N);
        mask = (X-cx).^2 + (Y-cy).^2 <= rr^2;
        mask = mask & (typeMap_Barca==0);
        typeMap_Barca(mask) = 3;
        idMap_Barca(mask) = nextID;
        nextID = nextID + 1;
    end
end