function stampa_riepilogo(boatPos, victimPos, pathRows, pathCols, costMap, boatRow, boatCol)
    % Print the final summary
    
    fprintf('Boat: (%d, %d)\n', boatPos(1), boatPos(2));
    fprintf('Victim: (%d, %d)\n', victimPos(1), victimPos(2));
    
    obstacleMask = (costMap == Inf);
    obstacleDistances = bwdist(obstacleMask);
    fprintf('Nearest obstacle distance: %.1f px\n', obstacleDistances(boatRow, boatCol));
    
    if ~isempty(pathRows)
        path_len = sum(sqrt(sum(diff([pathRows, pathCols]).^2,2)));
        fprintf('Path: %d steps, %.1f px\n', size(pathRows,1), path_len);
    else
        fprintf('Path: NOT FOUND\n');
    end
end