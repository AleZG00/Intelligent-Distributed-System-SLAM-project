function [pathR, pathC] = reconstruct_path(parent, sr, sc, gr, gc)
    % Reconstructs the path from the parent tree
    
    path = [gr, gc];
    cr = gr; cc = gc;
    
    while ~(cr == sr && cc == sc)
        prev_r = parent(cr, cc, 1);
        prev_c = parent(cr, cc, 2);
        path = [prev_r, prev_c; path];
        cr = prev_r;
        cc = prev_c;
    end
    
    pathR = path(:, 1);
    pathC = path(:, 2);
end