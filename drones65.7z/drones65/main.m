clc;
close all;
clear;

% ADD FOLDER TO MATLAB PATH
addpath('funzioni_droni');
addpath('funzioni_barca');

% REMOVE LATEX INTERPRETATION OR USE 'none' FOR TITLES
set(0,'defaulttextinterpreter','none')
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
set(0,'DefaultFigureWindowStyle','docked');
set(0,'defaultAxesFontSize',  22)
set(0,'DefaultLegendFontSize',  20)

visu = 1; % 1 = visualize map, 0 = no visualization
visualize_in_real_time = 1;

CCD_synchro_start = 0;
ID_known_perc = 0.6; % How many ID's are known (How many remarks has the map in %)
drones_num = 3; % number of drones
sigma_radar = 1.5;
sigma_radar = ones(1,drones_num)*sigma_radar;  % The higher the value the worst the drone can see
sigma_velocity = 2;
sigma_velocity = ones(1,drones_num)*sigma_velocity;
sigma_velocity(2) = 1;
sigma_radar(2) = 0.5;
gamma = 0.3; % variable that controls how much the filter trusts less measurements based on the uncertainty in the position
FinishRandomStep = 1; % How long the drones move randomly before exploring new areas
minDist = 500; % Minimum distance from the victim
Drones_radius = 35;

% Parameters
maxSteps = 1500; % Maximum duration of the simulation
connectionRange = 70;
viewRadius = 70; % Area of the drone visual range (in px)
Start_angle = zeros(1,drones_num);
for i=1:drones_num
    Start_angle(i) = round(rand*360);
end
angles_formation = zeros(1,drones_num);
dist = zeros(drones_num,2);
Start_angle = 90;
% Half circle formation
% for k = 0:drones_num-2
%     angles_formation(k+2) = pi/2 + (2*k)*pi/(2*(drones_num-2));
%     dist(k+2,:) = [cos(angles_formation(k+2)) sin(angles_formation(k+2))]*Drones_radius;
% end

% I formation
for k = 0:drones_num-2
    dist(k+2,:) = [0 ceil((k+1)/2)*(-1)^k]*Drones_radius;
end

% Drones setup respect to drone 1
wait_iterations = 6; % how much time drone 1 gives the other drones to get in formation
count = 0; % Timer for drone 1 so it waits the other drones get in formation
min_certainty = 0.75; % how uncertain the drones can be about if they found the target
drones_max_vel = 10; % velocity of the drones in km/h
vel = drones_max_vel;

p_init = 1000;% initial uncertainty, drones start in a position with almost no uncertainty  
P = diag(ones(1,drones_num*2))*p_init; % Covariance matrix init.

%% Map creation
fprintf('MAP CREATION \n');
[typeMap, idMap, ~] = crea_mappa_base();
idMap_boat = idMap;

types = [2 3 4 5]; 

%% Victim positioning
[typeMap, idMap_boat, victimPos, victimRow, victimCol] = posiziona_vittima(typeMap, idMap_boat, types);

if ~exist('immagini', 'dir')
    mkdir('immagini')
end

%% Random Obstacles Removal
idMap_boat = rimuovi_ostacoli_casuali(idMap_boat, ID_known_perc,types);
idMap= rimuovi_ostacoli_casuali(idMap_boat, ID_known_perc,types);
figure
    subplot(1,2,1);
    imagesc(idMap); axis equal tight;
    hold on;
    plot(victimPos(1), victimPos(2), 'k*','Color', [0.9 0.9 0.9], 'MarkerSize', 10, 'LineWidth', 2);
    title('Map with all labeled IDs');
    set(gca, 'YDir', 'normal');


idMap_flat = idMap(:);                        % flatten matrix into vector
[~, firstIdx] = unique(idMap_flat, 'first');  % find first occurrence indices
mask = true(size(idMap_flat));                % initialize mask as all true
mask(firstIdx) = false;                       % mark first occurrences as NOT duplicates
idMap_flat(mask) = 0;                         % replace duplicates with 0
idMap = reshape(idMap_flat, size(idMap));

    subplot(1,2,2);
    imagesc(typeMap); axis equal tight;
    hold on;
    plot(victimPos(1), victimPos(2), 'k*','Color', [0.9 0.9 0.9], 'MarkerSize', 10, 'LineWidth', 2);  
    title('Map with all obstacles, the white star is the target');
    set(gca, 'YDir', 'normal');
    % colorbar('Ticks',[0 1 2 3 4], 'TickLabels', {'0:Water', '1:Cliff', '2:Barrier', '3:Buoy', '4:Reef'});
    clim([0 5]);
exportgraphics(gcf,'immagini/2_Map_with_reduced_IDs.pdf','ContentType','vector')


%% Cost-Map Creation
[costMap, obstacleMask] = crea_cost_map(typeMap, victimRow, victimCol);
for i =-1:1
    for j = -1:1
        typeMap(victimRow+j, victimCol+i) = 50;
    end
end

%% Drones movement 
% PARAMETERS
N = 1000;                            
nextID  = 1;

% To avoid that the drones find at first step the objective we ashure the
% drones start at at least 500 m from the victim
starts = generateDroneStartPositions(victimPos, drones_num, N, minDist);

dronePos = zeros(drones_num,2);
for i = 1:drones_num
    dronePos(i,:) = starts(i,:);
end

% Initialize drone position (true and believed)
Bpos = ones(drones_num,2).*500; 

% Helper variables init
stateMap = zeros(drones_num, N, N); % Initialize empty maps for each drone (each starts unaware of obstacles)
% for i = 1:drones_num
%     xk(i*2 - 1:i*2,1) = starts(i,:)';
% end
xk = ones(drones_num*2,1).*501;


v = zeros(drones_num*2,1);
avgUncertaintyHistory = zeros(drones_num, maxSteps);  
Pos_error = zeros(drones_num, maxSteps);
actual_movement = [0,0];
uncertain_steps = ones(drones_num,2).*25;

countTri = ones(drones_num,1);
dir = zeros(drones_num,2);
dk = zeros(drones_num,4);  
uk = zeros(drones_num*2,3);
Pos = zeros(drones_num*2,4);
anchor_id = zeros(drones_num,1);
vT = zeros(drones_num,1);
Origin = Bpos;

%Flags
victimFound = false;
finish = false;
founder = 0;
% ok = [false false false];
% ok23 = [false false];
% ok32 = false;
AtVictim = false;
flagCF = false;
in = zeros(drones_num,1);
transform = zeros(drones_num,1);
flagPE = false; % To make the drones start togheter in the CCD
finishPE = zeros(drones_num,1);

finalStep = maxSteps;
theta_deg = [0, 0, 0]; % CCW rotation to allign map 1 to 2, 2 to 3, and 1 to 3

% Plot of the true map
figure;
hold on;
imagesc(typeMap);
plot(victimPos(1), victimPos(2), 'k*','MarkerSize', 12, 'LineWidth', 2);
axis equal tight;
title('Full map with true positions')
colors = lines(drones_num);
clim([0 5]);
for d = 1:drones_num
    hPoints(d) = plot(nan, nan, 'o', 'Color',  colors(d,:), 'MarkerSize', 6, 'LineWidth', 1.5);
end
exportgraphics(gcf,'immagini/SpecialCase.pdf','ContentType','vector')
%% --- Fusion state for every cell ---
P0      = 1;               % initial variance for every cell cause no trasformation is to be made corresponds to the measurement covariance matrix 
uncertainty_Map  = repmat( P0, [drones_num,N, N] ); 


Previous_dir = zeros(drones_num,2);
for i = 1:drones_num
    theta = 2*pi*rand;
    Previous_dir(i,:) = [cos(theta) sin(theta)];% Starting direction of the drones
end 

localIdMap = zeros(drones_num, N, N);

%% Map partition

% Dynamic map partition
GridPartition = 4; % 4X4 sudivision
RD = N/GridPartition;
BD = RD/2;
S = zeros(drones_num,GridPartition,GridPartition,3);% (:,:,:,1:2) row and col, (:,:,:,3) zero to be setted, (:,:,:,4) cuadrant number
% countMap = 1; % define sector number
for j = 1:GridPartition
    for i = 1:GridPartition
        S(:,i,j,1) = RD*i-BD;
    end
end
for j = 1:GridPartition
    for i = 1:GridPartition
        S(:,j,i,2) = RD*i-BD;
        % S(:,j,i,4) = countMap;
        % countMap = countMap +1;
    end
end
target = zeros(drones_num,2);

% Boustrophedon cellular decomposition (CCD)

w_EA = N/drones_num;
tolx = viewRadius/1.5; % how wide should the drones go in x direction
toly = viewRadius/10; % tollerance on how big should be the climbing between rows
n = N/(viewRadius-toly);
h_EP = N*2/n;

EP = zeros(round(n)*2,drones_num*2);

for i=1:drones_num
    for j=1:round(n)
         EP(j*2-1,i*2-1:i*2) = [(i-1)*w_EA, (j-1)*h_EP] + (viewRadius-tolx);
         EP(j*2,i*2-1:i*2) = [i*w_EA - (viewRadius-tolx), (j-1)*h_EP + (viewRadius-tolx)];
    end
end
for k = 1:round(n)+1
    if mod(k,2) == 0      % even block → swap rows
        r1 = 2*k - 1;
        r2 = 2*k;
        EP([r1 r2], :) = EP([r2 r1], :);
    end
end
[numRows, numCols] = size(EP);
% Identify column blocks: 3-4, 7-8, 11-12, ...
for cb = 1:floor((numCols)/4)
    c1 = 4*cb - 1;   % first column of block
    c2 = 4*cb;       % second column of block
    
    % For each pair of rows (1↔2, 3↔4, ...)
    for r = 1:2:numRows
        if r+1 <= numRows
            EP([r r+1], [c1 c2]) = EP([r+1 r], [c1 c2]);
        end
    end
end

PE = ones(1,drones_num);
oddIdx  = 1:2:drones_num*2;
evenIdx = 2:2:drones_num*2;


%% Real time maps setup

%— set up local‐map figure —

rows = ceil(sqrt(drones_num));
cols = ceil(drones_num / rows);

fig1 = figure; clf;
for d = 1:drones_num
    axMap(d) = subplot(cols,rows,d);           %# axes handles
    hold on;
    % initial blank image
    hImg(d) = imagesc( squeeze(stateMap(d,:,:)) );
    set(axMap(d), 'YDir','normal', 'NextPlot','add');
    hPoint(d) = plot(NaN, NaN, 'o', 'Color', colors(d,:), ...
                     'MarkerSize',6, 'LineWidth',1.5);
    hPoints2(d) = plot(nan, nan, 'o', 'Color', 'k', 'MarkerSize', 6, 'LineWidth', 1.5);
    % hPoints(d) = plot(nan, nan, 'o', 'Color', 'k', 'MarkerSize', 6, 'LineWidth', 1.5);
    title(axMap(d), sprintf('Drone %d Map', d));
    axis(axMap(d), 'equal','tight');
    colorbar('Ticks',[0 1 2 3 4]);
    clim([0 5]);
end
drawnow;

%— set up uncertainty figure —
fig2 = figure; clf;
for d = 1:drones_num
    axUnc(d) = subplot(cols,rows,d);
    hUnc(d)  = imagesc( squeeze(uncertainty_Map(d,:,:)) );
    set(axUnc(d), 'YDir','normal');
    colorbar;
    % clim([0 1]);
    title(axUnc(d), sprintf('Drone %d Uncertainty', d));
    axis('equal','tight');
end
drawnow;


% Figure for Position Error
figErr = figure; clf;
axErr = axes(figErr);
hold(axErr,'on')
for d = 1:drones_num
    hErr(d) = plot(axErr,nan, nan, '-', 'Color', colors(d,:), 'LineWidth', 2);
end
grid on;
grid minor;
xlabel(axErr,'Step [#]');
ylabel(axErr,'Absolute Position Error [m]');
titles = compose('Drone %d', 1:drones_num);
legend(axErr,titles, 'Location','best');
ylim(axErr,[0,100])
title(axErr,'Position Error Over Time');

%% Boat Placement
[costMap_Barca, obstacleMask_Barca] = crea_cost_map_Barca(typeMap, victimRow, victimCol);
[typeMap_Barca, idMap_boat] = crea_mappa_base_Barca();
[boatPos, boatRow, boatCol, start] = posiziona_barca_sicura(costMap_Barca, idMap_boat, victimRow, victimCol);

%% Main loop
R_map_evolution = zeros(drones_num,maxSteps);
regrup_pos = [0,0];

choice = questdlg('Which exploration strategy do you want to run?', ...
                  'Exploration strategy selection', ...
                  'Boustrophedon cellular decomposition','Random space partition','Just Random', ...
                  'Boustrophedon cellular decomposition');

% Main loop
for step = 1:maxSteps
    for d = 1:drones_num
        if finish, continue; end
        
        % drones distance to the targets
        dist_to_target = sqrt( (Bpos(:,1) - regrup_pos(1)).^2 + (Bpos(:,2) - regrup_pos(2)).^2 );

        % Move and update position
        if victimFound == false && step < FinishRandomStep || transform(d) == false % Random exploration
            exploreDir = chooseExplorationMove(Bpos(d,:), N, viewRadius,d,Previous_dir(d,:));
            if exploreDir == Previous_dir(d,:)
                exploreDir = chooseExplorationMove(dronePos(d,:), N, viewRadius,d,Previous_dir(d,:));
            end
        vel = drones_max_vel;
      
        elseif victimFound == false && step >= FinishRandomStep && transform(d) == true % Uncertain zones exploration
            % Extract 2D uncertainty map for drone d
            
            switch choice
                case 'Random space partition'
                map2D = squeeze(uncertainty_Map(d,:,:));
                gp = Bpos(d,:);

                for i=1:GridPartition
                    for j=1:GridPartition
                        if all(all(map2D(1+(i-1)*RD:i*RD, 1+(j-1)*RD:j*RD)<min_certainty)) && S(d,i,j,3) == 0
                            S(d,i,j,3) = 1; % squeeze(S(d,:,:,3))
                        end
                    end
                end
    
                distMatrix = squareform(pdist(dronePos));  % pairwise Euclidean distances
                connected = distMatrix < connectionRange;
                connected = (connected - diag(diag(connected))).*(transform*transform');
    
                if any(find(connected(d,:),1))
                    if d > find(connected(d,:),1) && all(target(d,:)==0)
                        unexplored = (squeeze(S(d,:,:,3)) == 0);   % 4x4 logical matrix
                        [i0, j0] = find(unexplored); 
                        quadCenters = zeros(length(i0),2);
        
                        for i=1:length(i0)             
                            quadCenters(i,:) = squeeze(S(d, i0(i), j0(i), 1:2))';
                        end
        
                        
                        pos = Bpos(d,:);
                        distances = vecnorm(quadCenters - pos, 2, 2);  % Euclidean distance
                        [~, idxMax] = max(distances);
                        [~, idxMin] = min(distances);
                        S(d, i0(idxMax), j0(idxMax), 3) = 1;
                        S(d, i0(idxMin), j0(idxMin), 3) = 1;
                        target(d,:) = quadCenters(idxMax, :);
                        % t = target(d,2);
                        % target(d,2) = target(d,1); 
                        % target(d,1) = t;
                        
                    end
                end
    
                % Find the maximum uncertainty value
                maxVal = max(map2D(:));
                
                % Find all positions that have that maximum uncertainty
                [rows, cols] = find(map2D == maxVal);
                
                % Compute Euclidean distances from the drone's current position
                % Note: Bpos(d,:) = [x, y], but rows correspond to y and cols to x 
    
                distances = sqrt((cols - gp(1)).^2 + (rows - gp(2)).^2);
                
                % --- Select distances between 30 and 80 ---
                [~, selectedIdx] = min(distances);
                
                if sqrt((target(d,1) -  gp(1)).^2 + (target(d,2) - gp(2)).^2) < 20
                    target(d,:) = [0 0];
                end
                
                % Select the target coordinate [x, y]
                go_to_uncert = [cols(selectedIdx), rows(selectedIdx)];
                
                if any(target(d,:))
                    go_to_uncert = target(d,:);
                end

                % Compute the direction vector toward that point
                [exploreDir,vel] = directedMovement(gp, go_to_uncert);
                case 'Boustrophedon cellular decomposition'

                     gp = Bpos(d,:);
                     [exploreDir,vel] = directedMovement(gp, EP(PE(d),[d*2-1 d*2]));
                     distanceD = sqrt((EP(PE(d),d*2-1) - gp(1)).^2 + (EP(PE(d),d*2) - gp(2)).^2);
                     
                     distance = sqrt((EP(PE(d),oddIdx)' - Bpos(:,1)).^2 + (EP(PE(d),evenIdx )' - Bpos(:,2)).^2);
                     
                     if CCD_synchro_start
                         if all(distance < 5)   
                             flagPE = true;
                         end
    
                        if distanceD < 5 && flagPE == true &&  finishPE(d) == 0
                            
                            if PE(d) == size(EP,1)
                                finishPE(d) = 1;
                                
                                continue
                            end
                            PE(d) = PE(d) + 1;
                           
                        end
                        if all(finishPE)   
                             finish = true;
                             CF_step = step;
                        end
                     else
                        if distanceD < 5
                             PE(d) = PE(d) + 1;
                        end
                        if all(finishPE)   
                             finish = true;
                             CF_step = step;
                        end

                     end

                otherwise
                map2D = squeeze(uncertainty_Map(d,:,:));
    
                % Find the maximum uncertainty value
                maxVal = max(map2D(:));
                
                % Find all positions that have that maximum uncertainty
                [rows, cols] = find(map2D == maxVal);
                
                % Compute Euclidean distances from the drone's current position
                % Note: Bpos(d,:) = [x, y], but rows correspond to y and cols to x
                gp = Bpos(d,:);
    
                distances = sqrt((cols - gp(1)).^2 + (rows - gp(2)).^2);
                
                % --- Select distances between 30 and 80 ---
                [~, selectedIdx] = min(distances);
                
                
                % Select the target coordinate [x, y]
                go_to_uncert = [cols(selectedIdx), rows(selectedIdx)];
                
                % Compute the direction vector toward that point
                [exploreDir,vel] = directedMovement(gp, go_to_uncert);
            end
             

        elseif all(dist_to_target<= 25) && flagCF == false % Flag for when all drones are at the victim and go to the boat in formation
            AtVictim = true;
            regrup_pos = boatPos;
            
            CF_step = step;
            flagCF = true;
            
        elseif all(regrup_pos == boatPos) && d ~= 1 % Put drones in formation
            [exploreDir,vel] = directedMovement(Bpos(d,:),Bpos(1,:) + dist(d,:));
            

        elseif dist_to_target(1) <= 25 && all(regrup_pos == boatPos) % Exit of the main loop
            finish = true;

        elseif all(regrup_pos == boatPos) && d == 1 && count > wait_iterations % Path so drone 1 goes to the boat
            [exploreDir,vel] = directedMovement(Bpos(d,:),regrup_pos);
            vel = min(drones_max_vel*7/10,vel);

        elseif d == 1 && count < wait_iterations && victimFound == true && all(regrup_pos == boatPos) % Time drone 1 has to wait so other drones get in formation
            exploreDir = [0,0];
            count = count + 1;

        elseif dist_to_target(d) < 15 % If the a drone reaches the victim, wait the others
            exploreDir = [0,0];

        elseif dist_to_target(d) >= 15 % Direction so other drones get to the victim
            [exploreDir,vel] = directedMovement(Bpos(d,:),regrup_pos);
        end
        
        if any(dir(d,:)~= 0)
            exploreDir = dir(d,:);
            vel = vT(d);
        end
        Previous_dir(d,:) = exploreDir; % save of the previous direction for maintaining the direction at eact step
        
        % Direction where the drone believes is moving
        believed_movement = exploreDir .*min(drones_max_vel,vel) ;

        % True direction influenced by drone intrinsic error and other
        % possible extern factors like wind or strikes with birds
        actual_movement = exploreDir .* (min(drones_max_vel,vel) + randn*sigma_velocity(d)*min(drones_max_vel,vel)/drones_max_vel);  
        
        % Movement obtained at current step
        v = zeros(drones_num*2,1);
        v(d*2 - 1) = believed_movement(1);
        v(d*2) = believed_movement(2);

        % Position update
        xk = xk + v;

        % Noise increase
        Qk = zeros(drones_num*2);
        Qk(d*2 - 1, d*2 - 1) = sigma_velocity(d)^2*min(drones_max_vel,vel)/drones_max_vel;
        Qk(d*2, d*2) = sigma_velocity(d)^2*min(drones_max_vel,vel)/drones_max_vel;

        % Covariance update
        P = P + Qk;

        % True nwe position
        dronePos(d,1) =  max(min(dronePos(d,1) + actual_movement(1), N), 1); % Update the dronePos with the new movement for the next iteration 
        dronePos(d,2) =  max(min(dronePos(d,2) + actual_movement(2), N), 1);

        
        Bpos(d,1) = max(min(xk(d*2 - 1), N), 1); % Function that avoids the drone going out of the boundaries
        Bpos(d,2) = max(min(xk(d*2), N), 1);
        
        % Update of the position calculated from the model
        xk(d*2 - 1) = Bpos(d,1);
        xk(d*2) = Bpos(d,2);

       % calculation to obtain the actual visibility range
        x = round(dronePos(d,1));
        y = round(dronePos(d,2));
        yrange = max(1, x-viewRadius):min(N, x+viewRadius);
        xrange = max(1, y-viewRadius):min(N, y+viewRadius);

        % calculation to obtain the believed visibility range so that 
        % the patch is placed where the drone thinks is
        % and if its nearer to the limit boundary doesn't attemp to
        % position values out of the map
        bx = round(Bpos(d,1));
        by = round(Bpos(d,2));
        byrange = max(1, bx-viewRadius):min(N, bx+viewRadius);
        bxrange = max(1, by-viewRadius):min(N, by+viewRadius);
        
        [ri, ci] = find(idMap(xrange, yrange) > 0);
        if size(ri,1)>0 && transform(d) == false

            [vT(d),xk,dir(d,:),stateMap(d,:, :),uncertainty_Map(d,:, :),countTri(d),dk(d,:),uk(d*2 - 1:d*2,:),in(d),Pos(d*2 - 1:d*2,:),transform(d),P, anchor_id(d)] =... 
                trilateration(min(drones_max_vel,vel),d,xk,dronePos(d,:), squeeze(stateMap(d,:, :)),squeeze(uncertainty_Map(d,:, :)),dir(d,:),idMap, xrange, yrange,...
                viewRadius,countTri(d),dk(d,:), actual_movement,uk(d*2 - 1:d*2,:),in(d),Pos(d*2 - 1:d*2,:),transform(d),P, anchor_id(d));

            if transform(d) == true
                FT_step = step;
                vel = drones_max_vel;
            end
        end
        
        Bpos(d,1) = xk(d*2 - 1);
        Bpos(d,2) = xk(d*2);
        
        % Function that when an obstacle with an Id is seen the drone can
        % correct his position using EKF (Linearization on the
        % exteroceptive model)
        if transform(d) == true
            [P,xk,uncertain_steps(d,:)]= estimateDronePose2(P,d,dronePos(d,:),xk,idMap,sigma_radar,xrange, yrange,uncertain_steps(d,:),viewRadius,step);
        end

        % Extract local map patch
        true_patch = typeMap(xrange, yrange); % What idealy the drone would see
        % noisy_patch = double(true_patch) + (sigma_radar(d) * randn(size(true_patch))); % What it actually sees cause of uncertainty


        % perform a WLS (Maximum Likelihood) update for each newly observed cell, done to
        % reduce the uncertainty of each seen cell
        for dx = 1:numel(xrange)
            for dy = 1:numel(yrange)

                if (viewRadius + dronePos(d,2) >= N && viewRadius + Bpos(d,2) >= N)||(dronePos(d,2) - viewRadius <= 1 && Bpos(d,2) - viewRadius <= 1)
                    i = max(min(xrange(dx), N), 1);
                elseif xrange(dx)+round(Bpos(d,2)-dronePos(d,2)) <= N && xrange(dx) + round(Bpos(d,2)-dronePos(d,2)) >= 1 
                    i = xrange(dx)+round(Bpos(d,2)-dronePos(d,2));
                end

                if (viewRadius + dronePos(d,1) >= N && viewRadius + Bpos(d,1) >= N)||(dronePos(d,1) - viewRadius <= 1 && Bpos(d,1) - viewRadius <= 1)
                    j = max(min(yrange(dy), N), 1);
                elseif yrange(dy)+round(Bpos(d,1)-dronePos(d,1)) <= N && yrange(dy)+round(Bpos(d,1)-dronePos(d,1)) >= 1 
                    j = yrange(dy)+round(Bpos(d,1)-dronePos(d,1));
                end

                z = true_patch(dx,dy);          % measurement
                R = min(P(d*2 - 1,d*2 - 1)+ P(d*2,d*2),25); 
                % measurement variance for drone d, the more 
                % the drone goes by without having estimates of it's
                % position from an ID the less it should be able to
                % positionate pixels in not certain positions
                

                p = [i j]; % Points rotation
                % if Start_angle(d) ~= 0
                %     center = Origin(d);  
                %     p_rot = rotatePointAroundCenter(p, center, Start_angle(d)); 
                % 
                %     if any(p_rot > N) || any(p_rot < 1) % if a point is out of boundaries discard it by putting them all in a dump position
                %         p_rot = [1,N];
                %     end
                %     p = max(min(p_rot, N), 1);               % clamp within [1, N]   
                % end

                %—— Prediction (identity dynamics) ——
                P_pred = uncertainty_Map(d,p(1), p(2)); 

                %—— update gain —— 
                W = P_pred / (P_pred + R); % Cause the variance is small the value is close to 1 so the prediction has a strong value in the estimation

                %—— Update ——
                x_prior         = stateMap(d,p(1), p(2)); % At beginning all 0 so new believe is strong, with every new measurment the value oscillates always less 
                stateMap(d,p(1), p(2))   = x_prior + W*(z - x_prior);
                uncertainty_Map(d,p(1), p(2))     = (1 - W)*P_pred; % Believe on each cell, the closer to 0 the higher is the belief of what was seen
                localIdMap(d, p(1), p(2)) = idMap(i, j);

            end
        end
        
        R_map_evolution(d,step) = R;

        % Rotation of the position
        p = Bpos(d,:);
        tp = dronePos(d,:);

        % Calculate which drones are enough close to comunicate their
        % position, map, and matrix covariances P
        
        distMatrix = squareform(pdist(dronePos));  % pairwise Euclidean distances
        connected = distMatrix < connectionRange;
        connected = (connected - diag(diag(connected))).*(transform*transform'); % remove self-connections
        

        if drones_num~=1
            for i = 1:drones_num
                neighbors{i} = find(connected(i,:));  % indices of drones connected to i
            end
        
        
            if AtVictim == 0 % Use Covariance intersection method untill all drones wont separate anymore
            [Bpos,P, uncertain_steps] = useDroneCPos(d,Bpos,dronePos,sigma_radar,P,neighbors,viewRadius,uncertain_steps);
            end
    
            % Join maps usign Metropolis Hastings method if all variances are
            % equal, or a row stochastic matrix to give more weight to the more
            % precise drones
            [stateMap, uncertainty_Map,localIdMap] = MH_map_fusion2(d, neighbors, stateMap, uncertainty_Map, sigma_velocity,P0, localIdMap, theta_deg);
            
            % Central Fusion algorithm so the drones account for the 
            % correlation in the estimates and all drones benefit from a new measuremnt
            if AtVictim == 1 
                [P,xk,p,uncertain_steps] = CentralFusionCL(d, xk, P, dronePos, sigma_radar, neighbors,viewRadius,uncertain_steps);
            % Rotation of the position
                % if true_angle(d) ~= 0
                %     tmp = p(1);
                %     p(1) = p(2);
                %     p(2) = tmp;
                %     center = [(N+1)/2, (N+1)/2];   
                %     p_rot = rotatePointAroundCenter(p', center, true_angle(d)); 
                %     p = max(min(p_rot, N), 1);     
                %     p1 = p(1);
                %     p(1) = p(2);
                %     p(2) = p1;
                % end
            end
        end

        if visualize_in_real_time == 1
            % Update local full true map
            % Update all drones’ maps & uncertainty

            % update local-maps images
            set( hImg(d), 'CData', squeeze(stateMap(d,:,:)) );

            % update uncertainty image
            set( hUnc(d), 'CData', squeeze(uncertainty_Map(d,:,:)) );
            %True-map figure
            set( hPoints(d), 'XData', dronePos(d,1),'YData', dronePos(d,2) );
            set( hPoints2(d), 'XData', tp(1),'YData', tp(2) );
            %believed drones position
            set( hPoint(d), 'XData', p(1),'YData', p(2) );

               % push the updates to the screen
            axis equal tight;
        end

       
        % Check if a drone found a cell which could be the victim, and if
        % the drone is secure more than 65% consider you found it
        A = squeeze(stateMap(d,:,:));
        [maxValue, linearIdx] = max(A(:));
        [rowM, colM] = ind2sub(size(A), linearIdx);
        if any(any(stateMap(d,rowM,colM,1) > 9)) && victimFound == false && uncertainty_Map(d,rowM,colM) < min_certainty

            A = squeeze(stateMap(d,:,:));
            [maxValue, linearIdx] = max(A(:));
            [rowVict, colVict] = ind2sub(size(A), linearIdx);
            p = [rowVict, colVict]; % Points rotation
            % if true_angle(d) ~= 0
            %     center = [(N+1)/2, (N+1)/2];  
            %     p_rot = rotatePointAroundCenter([rowVict, colVict], center, -true_angle(d)); 
            %     p = max(min(p_rot, N), 1);               % clamp within [1, N]   
            % end
            regrup_pos = [p(2) p(1)];

            fprintf('Drone %d found the victim at step %d!\n', d, step);
            victimFound = true;
            founder = d;
            step_VF = step;
        end
        % Uncertainty of each drone over the map and error between where
        % the drone believes it is and where actually is
        avgUncertaintyHistory(d, step) = mean(uncertainty_Map(d,:,:), 'all');
        Pos_error(:,step) = sqrt((dronePos(:,1)-Bpos(:,1)).^2+(dronePos(:,2)-Bpos(:,2)).^2);
        set(hErr(d),   'XData',1:step, 'YData', Pos_error(d,1:step));


    end

    drawnow;
    p=p+1;
    if finish 
        break; 
    end
end

avgUncertaintyHistory = avgUncertaintyHistory(:, 1:step-1);

%% Drone Figures
if victimFound == false
    founder = 1;
    fprintf('No drone was able to find the victim, standard deviation in position or radar too high!\n');
end


figure
drone_state_map = squeeze(stateMap(founder,:,:));
imagesc(drone_state_map)
title('Drone map')
axis equal tight;
colorbar;
clim([0 5]);
set(gca, 'YDir', 'normal');
exportgraphics(gcf,'immagini/9_Drone_map.pdf','ContentType','vector')

simt = linspace(1,step,step);
figure
sgtitle('Measurement noise covariance for the map recognition')
plot(simt,R_map_evolution(:, 1:step)')
legend(compose('Drone %d', 1:drones_num))
xlim([0 step])
xlabel('time step')
ylabel('R_map value')
exportgraphics(gcf,'immagini/10_Measurement_noise_covariance.pdf','ContentType','vector')

figure
simtP = linspace(1,step,step-FT_step+1);
sgtitle('Position error over time')
plot(simtP,Pos_error(:, FT_step:step)')
grid on;
grid minor
legend(compose('Drone %d', 1:drones_num))
xlabel('time step k')
ylabel('position error [m]')
xlim([0 step])
exportgraphics(gcf,'immagini/11_Position_error_over_time.pdf','ContentType','vector')

map_error = zeros(N,N);
mean_total_map_error = 0;
known_points = 0;

%% Map refinement to obtain a more cleaner image

rounded_state_map = squeeze(stateMap(founder,:,:));



for i=1:N
    for j=1:N
        if uncertainty_Map(founder,i,j)<0.5
            map_error(i,j) = abs(typeMap(i,j)-rounded_state_map(i,j));
            mean_total_map_error = mean_total_map_error + abs(typeMap(i,j)-rounded_state_map(i,j));
            known_points = known_points + 1;
        end
    end
end
% exportgraphics(gcf,'immagini/12_rounded_state_map.pdf','ContentType','vector')

RMS_pos_error = sqrt(mean(mean(Pos_error(:, FT_step:step).^2, 2)));
RMS_pos_error_CF = sqrt(mean(mean(Pos_error(:, CF_step:step).^2, 2)));
RMS_pos_error_BCF = sqrt(mean(mean(Pos_error(:, FT_step:CF_step).^2, 2)));

tot_map_exploration_perct = known_points/(N*N);

mean_total_map_error = mean_total_map_error/known_points;

fprintf('***************************************************\n               Simulation data \n')
fprintf('Mean error in the positioning of the obstacles in the created map is of %.2f%%\n',mean_total_map_error);
fprintf('***************************************************\n')

fileID = fopen('results.txt','a');

fprintf(fileID,'Simulation with %d drones\n', drones_num);
fprintf(fileID,'Percentage of known Landmarks over the whole map:%.2f%% \n', ID_known_perc);
fprintf(fileID,'Exploration methode:%s \n', choice);
if strcmp(choice,'Boustrophedon cellular decomposition') 
    fprintf(fileID,'Synchronized start:%d \n', CCD_synchro_start);
end
fprintf(fileID,'drones std of radar ');
fprintf(fileID, '%.2f ', sigma_radar);
fprintf(fileID, '\n');
fprintf(fileID,'drones std of velocity ');
fprintf(fileID, '%.2f ', sigma_velocity);
fprintf(fileID, ' m/s\n');
fprintf(fileID,'Mean error in the positioning of the obstacles in the created map is of %.2f\n',mean_total_map_error);
fprintf(fileID,'Ammount of map ecploration %.2f%%\n',tot_map_exploration_perct);
fprintf(fileID,'RMS position error:%.2f m\n', RMS_pos_error);
fprintf(fileID,'RMS position error when drones are using Central Fusion algorithm:%.2f m\n', RMS_pos_error_CF);
fprintf(fileID,'RMS position error when drones before using Central Fusion algorithm:%.2f m\n', RMS_pos_error_BCF);
fprintf(fileID,'Steps needed to find the victim:%d \n', step_VF);
fprintf(fileID,'----------------------------\n');

fclose(fileID);


figure
imagesc(map_error)
title('Absolute map error')
axis equal tight;
colorbar;
clim([0 5]);
set(gca, 'YDir', 'normal');
exportgraphics(gcf,'immagini/13_Absolute_map_error.pdf','ContentType','vector')
% How much each drone didn't knew about the map in time
figure;
plot(avgUncertaintyHistory');
xlabel('Step');
ylabel('Average Uncertainty');
legend(compose('Drone %d', 1:drones_num))
title('Uncertainty Reduction Over Time');
grid on;
exportgraphics(gcf,'immagini/14_Uncertainty_Reduction_Over_Time.pdf','ContentType','vector')

%% Safety Map Creation with Buffer for Boat
fprintf('\nSAFETY MAP CREATION WITH BUFFER \n');
safetyDistance = 10;
victimSafetyDistance = 25;
goal = [victimRow, victimCol];

safetyMap = crea_safety_map_typeMap(rounded_state_map, boatPos, victimPos, safetyDistance, victimSafetyDistance);
safetyMap2 = crea_safety_map_typeMap(typeMap, idMap_boat, victimPos, safetyDistance, victimSafetyDistance);

%% Path Calculation with A*
fprintf('\nPATH CALCULATION WITH A* \n');
[pathRows, pathCols, success] = improved_astar_with_safety(safetyMap, start, goal);
if ~success
    fprintf('First attempt failed, trying with normal complex map...\n');
    [pathRows, pathCols, success] = improved_astar_with_safety(safetyMap2, start, goal);
end

%% Final Results Visualization
visualizza_risultati_finali(rounded_state_map, victimPos, boatPos, pathRows, pathCols, success);
exportgraphics(fig1,'immagini/4_local_map.pdf','ContentType','vector')
exportgraphics(fig2,'immagini/5_uncertainty_map1.pdf','ContentType','vector')
exportgraphics(figErr,'immagini/7_position_error.pdf','ContentType','vector')

%% Summary
fprintf('\nSUMMARY \n');
stampa_riepilogo(boatPos, victimPos, pathRows, pathCols, costMap, boatRow, boatCol);

fprintf('\nSIMULATION COMPLETED !!!\n');

