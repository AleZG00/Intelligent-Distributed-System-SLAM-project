function [P, believed_pos,uncertain_steps] = estimateDronePose2(P, d, dronePos, x_model, idMap, sigma_radar, xrange, yrange,uncertain_steps,viewRadius,step)
% estimateDronePose2  EKF correction using visible landmark IDs in patch
% Inputs:
%   P          - prior covariance
%   d          - drone index (1..N) being processed
%   dronePos   - [xreal, yreal] true position (used to simulate measurement)
%   x_model    - Nx1 believed stacked state [x1;y1;x2;y2;x3;y3...]
%   idMap      - global id map (NxN) of landmark IDs
%   sigma_radar- vector of radar std per drone (sigma, not variance)
%   xrange,yrange - vectors indicating the submatrix indices used (rows,cols)
%
% Outputs:
%   P            - updated covariance
%   believed_pos - updated state
%   uncertain steps (how many steps passed from last time a drone saw an
%   ID)

    N = size(P,1);
    % Extract the IDs observed in the patch (submatrix of idMap)
    seenIds = idMap(xrange, yrange);   % matrix (rows = length(xrange), cols = length(yrange))

    % find nonzero IDs inside the patch (row/col indices within seenIds)
    [ri, ci] = find(seenIds > 0);
    if isempty(ri)
        % no anchors seen -> no correction
        believed_pos = x_model;
        uncertain_steps(1) = uncertain_steps(1) + 1;
        return;
    end

    % Convert the local patch indices (ri,ci) to global coordinates (row, col)
    % Note: idMap uses (row, col) indexing. We'll interpret columns as X and rows as Y.
    observedIDs = seenIds(sub2ind(size(seenIds), ri, ci));

    
    uniqueIDs = unique(observedIDs);
    uniqueIDs(uniqueIDs == 0) = [];
    anchors = []; % Nx2 [x, y] (x = col, y = row)
    for k = 1:numel(uniqueIDs)
        idk = uniqueIDs(k);
        [ri, ci] =  find(idMap == idk);
        anchors(end+1, :) =  [ci, ri];
    end


    % Build stacked measurement vector z, predicted measurement h_pred, Jacobian H
    m = size(anchors,1);          % number of landmark measurements available
    z = zeros(m,1);
    h_pred = zeros(m,1);
    H = zeros(m, N);             % m x (N*2) (state dimension of each = 2)
    idx_x = d*2 - 1;             % index of drone's x in x_model
    idx_y = d*2;                 % index of drone's y in x_model

    % predicted drone position from belief (for linearization)
    px_hat = x_model(idx_x);
    py_hat = x_model(idx_y);

    % Simulate / gather measurements for each anchor
    for k = 1:m
        ax = anchors(k,1);      % anchor x (col)
        ay = anchors(k,2);      % anchor y (row)

        % true range measurement simulated from real position of drone
        xreal = dronePos(1); yreal = dronePos(2);
        z_true = sqrt( (xreal - ax)^2 + (yreal - ay)^2 );

        % measurement noise: randn * sigma 
        z(k) = z_true + z_true/viewRadius*sigma_radar(d)*randn;

        % predicted measurement (range) from belief
        dx = px_hat - ax;
        dy = py_hat - ay;
        r_pred = sqrt(dx^2 + dy^2);
        if r_pred < 1e-6
            r_pred = 1e-6; % numerical safety
        end
        h_pred(k) = r_pred;

        % Jacobian row: partial derivatives wrt to the drone states
        H(k, idx_x) = dx / r_pred;    % dh/dx
        H(k, idx_y) = dy / r_pred;    % dh/dy
        % other columns remain zero
    end

    % build measurement covariance (assume independent measurements)
    % measurement noise variance for this drone
    R_scalar = (z_true/viewRadius*sigma_radar(d))^2;
    Rmat = R_scalar * eye(m);

    % EKF update 
    S = H * P * H' + Rmat;     % innovation covariance (m x m)
    
    % Compute Kalman gain (n x m)
    W = (P * H') / S;
    
    % update state and covariance
    x_model = x_model + W * (z - h_pred);
    I = eye(N);
    P = (I - W * H) * P;

    believed_pos = x_model;
    uncertain_steps(1) = 0;
    uncertain_steps(2) = step;
end
