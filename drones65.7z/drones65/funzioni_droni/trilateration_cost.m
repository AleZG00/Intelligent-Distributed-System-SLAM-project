function r = trilateration_cost(X, dk, uk, A, N)

    % Reshape positions
    P = reshape(X, [2,N])';    % 3x2

    r = [];

    % 1) Distance constraint (N equations)
    for k = 1:N
        r = [r;
             norm(P(k,:)' - A) - dk(k)];
    end

    % 2) Motion constraint (N-1 steps => (N-1)x2 equations)
    for k = 1:N-1
        r = [r;
             (P(k+1,:)' - P(k,:)' - uk(:,k))];
    end

end
