function [P,x_model,p,uncertain_steps] = CentralFusionCL(d, x_model, P, dronePos, sigma_radar, neighbors,viewRadius,uncertain_steps)
% Central fusion algorithm for when the drones are always connected

xreal = dronePos(d,1); yreal = dronePos(d,2);
    idx_x = d*2 - 1;             % index of drone's x in x_model
    idx_y = d*2;                 % index of drone's y in x_model

    D = size(dronePos,1);         % number of drones

for i = 1:length(neighbors{d})
    neig = neighbors{d}(i);
    xreal2 = dronePos(neig,1); yreal2 = dronePos(neig,2);
    z_true = sqrt( (xreal - xreal2)^2 + (yreal - yreal2)^2 ); 

    zr = z_true + z_true/viewRadius*sigma_radar(d)*randn;

    idx_x2 = neig*2 - 1;             % index of drone's x in x_model
    idx_y2 = neig*2;                 % index of drone's y in x_model

    % predicted drone position from belief (for linearization)
    px_hat = x_model(idx_x);
    py_hat = x_model(idx_y);
    px_hat2 = x_model(idx_x2);
    py_hat2 = x_model(idx_y2);


    % predicted measurement (range) from belief
    dx = px_hat - px_hat2;
    dy = py_hat - py_hat2;
    r_pred = sqrt(dx^2 + dy^2);
    hab = r_pred;

    ra = zr - hab;
    Ha_tilde = [dx/r_pred, dy/r_pred];
    Hb_tilde = -Ha_tilde; % Because we measure the same way, 
    % and the distances have to be positive
    R_scalar = (z_true/viewRadius*sigma_radar(d))^2;

    Hab = zeros(1,D*2);
    Hab(d*2 - 1:d * 2) = Ha_tilde;
    Hab(neig*2 - 1:neig * 2) = Hb_tilde;

    Sab = Hab*P*Hab' + R_scalar;
    K = P*Hab'/Sab;
    x_model = x_model + K*ra;
    P = P - K*Sab*K';
    if uncertain_steps(neig,2) > uncertain_steps(d,2) && uncertain_steps(neig,1) < uncertain_steps(d,1)
        uncertain_steps(d,1) = uncertain_steps(neig,1);
    end
end
    
p = x_model(idx_x:idx_y);


end