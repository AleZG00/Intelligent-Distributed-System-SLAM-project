function [theta_deg, B, Tm, Um, ok, matchedIDs] = estimateOrientationFromIDs(A, B, Tm, Um, N, varargin)
% estimateOrientationFromIDs  Estimate rotation angle (deg) between two ID maps
%
% [theta_deg, B, Tm, Um, ok, matchedIDs] = estimateOrientationFromIDs(A, B, Tm, Um, N, 'minMatches', 3, 'refineDeg', 5)
%
% INPUTS
%   A, B,Tm, Um, N, varargin    - integer maps (size NxM). Nonzero entries are object IDs.
%                                 A is the reference map, B is the donor
%                                 map to rotate, and Tm, Um the other maps
%                                 that must also be rotated
%  NAME-VALUE
%   'minMatches' - minimum number of distinct shared IDs required (default 3)
%   'refineDeg'  - integer degree radius for local refinement around initial angle (default 3)
%
% OUTPUTS
%   theta_deg   - estimated rotation (degrees) to apply to B to align to A (CCW positive)
%   ok          - logical true if valid solution found (enough non-collinear matches)
%   B,Tm,Um     - Map rotated at theta_deg
%   matchedIDs  - list of matched shared IDs used for the estimate
%

% Parse options
p = inputParser;
addParameter(p, 'minMatches', 3, @(x)isnumeric(x) && x>=1);
addParameter(p, 'refineDeg', 0, @(x)isnumeric(x) && x>=0);
parse(p, varargin{:});
minMatches = p.Results.minMatches;
refineDeg = p.Results.refineDeg;

theta_deg = 0;
ok = false;
matchedIDs = [];

% Basic checks
if ~isequal(size(A), size(B))
    error('A and B must be the same matrix size');
end
[Nr, Nc] = size(A);

% fast method: for each id present, retrieve (col,row)
idsA = unique(A(A>0))';
idsB = unique(B(B>0))';
sharedIDs = intersect(idsA, idsB);

if numel(sharedIDs) < minMatches
    return; % not enough shared IDs
end

ptsA = zeros(0,2); % [x y] = [col row]
ptsB = zeros(0,2);
AllPtsB = zeros(0,2);
usedIDs = [];

for id = sharedIDs
    % find pixels with this id in A and B
    [rA, cA] = find(A == id, 1, 'first');
    [rB, cB] = find(B == id, 1, 'first');
    
    % Rigid transformation to rotate around the map center
    ptsA(end+1, :) = [cA - (N+1)/2, rA - (N+1)/2];
    ptsB(end+1, :) = [cB - (N+1)/2, rB - (N+1)/2];
    usedIDs(end+1) = id; 
end

for id = idsB
    % find pixels with this id in B
    [rB, cB] = find(B == id, 1, 'first');
    
    % Rigid transformation to rotate around the map center
    AllPtsB(end+1, :) = [cB - (N+1)/2, rB - (N+1)/2]; 
end

% --- 2) check non-collinearity 
% compute rank of ptsA to see if values are a linear combination of
% each other
C = ptsA;
if rank(C) < 2
    % collinear (or almost). fail
    return;
end


% --- 3) compute rotation via Kabsch (rotation-only) ---
% center the points
% muA = mean(ptsA,1)';
% muB = mean(ptsB,1)';
X = (ptsB)'; % 2xM points (source)
Y = (ptsA)'; % 2xM points(target)

H = X * Y';
[U,~,V] = svd(H);
R = V * diag([1,det(V*U')]) * U';

theta_rad = atan2(R(2,1), R(1,1));
theta_deg_est = mod(rad2deg(theta_rad), 360);

% --- 4) optional integer-degree refinement to maximize exact overlap ---
% We'll test integer-degree angles in [theta_deg_est - refineDeg, theta_deg_est + refineDeg]
searchAngles = round(theta_deg_est) + (-refineDeg:refineDeg);
searchAngles = mod(searchAngles,360);
bestAngle = round(theta_deg_est);
bestScore = 0;

% Precompute mapping info for overlap test:
% For each matched ID i, we know centroid in A (xa,ya) and B (xb,yb).
numMatches = size(ptsB,1);

for ang = searchAngles
    % rotation matrix for angle ang
    th = deg2rad(ang);
    Rtest = [cos(th), -sin(th); sin(th), cos(th)];
    % transform B centroids about their centroid muB to predicted positions in A-frame:
    % predicted_pts = Rtest * (ptsB' - muB) + muA
    pred = Rtest * ptsB'+ (N+1)/2; 

    % clamp to inside grid
    pred(1,:) = round(min(max(pred(1,:),1), Nc)); % col -> x
    pred(2,:) = round(min(max(pred(2,:),1), Nr)); % row -> y

    % Now count exact ID matches: for each k, check A(row,col) == id
    matchCount = 0;
    for k = 1:numMatches
        col_k = pred(1,k); row_k = pred(2,k);
        id_ref = A(row_k,col_k);
        if id_ref == usedIDs(k)
            matchCount = matchCount + 1;
        end
    end
    % score = fraction of matched IDs that fall exactly on the same cell after rounding
    sc = matchCount / max(1, numMatches);
    if sc > bestScore
        bestScore = sc;
        bestAngle = ang;
    else
        bestAngle = round(theta_deg_est);
    end
end

% Return results
theta_deg = mod(bestAngle,360); % - mod(bestAngle,5);
ok = (bestScore >= 0) && (numMatches >= minMatches);
matchedIDs = usedIDs;

% Rotation of the maps
Bnew = B;
if ok ~= 0
    Bnew = zeros(N,N);
    th = deg2rad(theta_deg);
    Rtest = [cos(th), -sin(th); sin(th), cos(th)];

    Brot = Rtest*AllPtsB'+ (N+1)/2;
    Brot(1,:) = round(min(max(Brot(1,:),1), Nc)); % col -> x
    Brot(2,:) = round(min(max(Brot(2,:),1), Nr)); % row -> y

    for i =1:length(idsB)
        col_k = Brot(1,i); row_k = Brot(2,i);
        Bnew(row_k,col_k) = idsB(i);
    end
    Bnew = max(Bnew,A);

end

B = Bnew;

Tprot = zeros(N,N);
Urot = ones(N,N);

for i = 1:N
    for j = 1:N
        % shift coords so center is (0,0)
        xy = [i - (N+1)/2; j -  (N+1)/2];

        % rotate coordinates
        xy_rot = Rtest * xy;

        % shift back
        i_rot = xy_rot(1) + (N+1)/2;
        j_rot = xy_rot(2) + (N+1)/2;

        % use nearest-neighbor interpolation
        i_src = round(i_rot);
        j_src = round(j_rot);

        % check bounds
        if i_src >= 1 && i_src <= N && j_src >= 1 && j_src <= N
            Tprot(i, j) = Tm(i_src, j_src);
            Urot(i, j) = Um(i_src, j_src);
        end
    end
end

Tm = Tprot;
Um = Urot;

end