function [v,xk,dir,map1,map2,count,dk,uk,in,Pos,transform,P, anchor_id] = trilateration(v,d,xk,dronePos,map1,map2,dir,idMap,...
    xrange, yrange,viewRadius,count,dk, actual_movement,uk,in,Pos,transform,P, anchor_id)

seenIds = idMap(xrange, yrange);

idx_x = d*2 - 1;             % index of drone's x in x_model
idx_y = d*2;                 % index of drone's y in x_model

newDir = [1 0; 0 1; -1 0; 0 0];

% Find all visible anchors
[~, ~, ids] = find(seenIds);

if isempty(ids) && anchor_id == 0
    return;
end

% If anchor not yet selected → choose the closest one
if anchor_id == 0

    xreal = dronePos(1);
    yreal = dronePos(2);

    distances = zeros(length(ids),1);

    for i = 1:length(ids)
        % real indices in full idMap
        [ri, ci] = find(idMap == ids(i));

        % distance to that anchor
        distances(i) = sqrt( (xreal - ci(1))^2 + (yreal - ri(1))^2 );
    end

    % Choose closest anchor
    [~, minIdx] = min(distances);
    anchor_id = ids(minIdx);

end

% Now use ONLY that anchor forever
idx = anchor_id;
[ri, ci] = find(idMap == idx);

xreal = dronePos(1);
yreal = dronePos(2);

% Distance to selected anchor
z_true = sqrt((xreal - ci(1))^2 + (yreal - ri(1))^2);

if count >= 2
    uk(:,count-1) = actual_movement';
    anchor_id = 0;
end

if z_true < viewRadius/2 || in == true
    in = true;
    Pos(:,count) = xk(idx_x:idx_y);
    dir = newDir(count,:);
    v = 1;
    dk(count) = z_true;
    count = count + 1; 
end

if in == false
    anchor_id = 0;
end

if count >= 5
    A = [ci(1); ri(1)];

% Number of poses used
N = 4;

% Initial guess: use current stored Pos
P0 = Pos';          % 3x2
X0 = P0(:);                 % [x1;y1; x2;y2; x3;y3]

% Residual function
cost = @(X) trilateration_cost(X, dk, uk, A, N);

% Solve
options = optimoptions('lsqnonlin','Display','off');
X = lsqnonlin(cost, X0, [], [], options);

% Extract corrected positions
P_est = reshape(X, [2,N])';   % 3x2

tras_needed = P_est(4,:)' - xk(idx_x:idx_y);

tx = round(tras_needed(1));
ty = round(tras_needed(2));

% mask1 = map1 > 0;
map1 = circshift(map1, [ty, tx]);

% mask2 = map2 < sigma_radar;
map2 = circshift(map2, [ty, tx]);

xk(idx_x:idx_y) = P_est(4,:)';
P(idx_x:idx_x,idx_x:idx_x) = 1;
P(idx_y:idx_y,idx_y:idx_y) = 1;
transform = true;
dir = [0 0];
end


end