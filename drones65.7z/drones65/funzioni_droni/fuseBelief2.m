function [stateMap, uncertainty_Map,merge_stepd1,merge_stepd2] = fuseBelief2(...
    d1, d2, stateMap, uncertainty_Map, sigma_velocity, P0, step,~)
% fuseBelief2  — share & fuse two drones' entire local maps at time step
% Uses uncertainty-weighted fusion to find consensus based on confidence
%
% Inputs:
%   d1, d2          : indices of the two drones
%   stateMap        : 3×N×N continuous estimates
%   uncertainty_Map : 6xNxN continuous estimates with uncertainty and time
%   connectionRange : scalar communication radius
%   dronePos        : 3×2 array of [x,y] positions
%   P0              : initial variance threshold (unseen if >=P0)
%   step            : actual time step
%
% Outputs:
%   stateMap, uncertainty_Map updated in place

    %  which cells each has seen
    C1 = squeeze(uncertainty_Map(d1,:,:));
    C2 = squeeze(uncertainty_Map(d2,:,:));
    seen1 = (C1 < P0);
    seen2 = (C2 < P0);
    merge_stepd1 = 0;
    merge_stepd2 = 0;
    
    % Return option for the first iteration to avoid an error 
    if ~any(seen1(:)) && ~any(seen2(:))
        return
    end

    %  Get state, uncertainty, and timestamp maps for both drones
    N = size(stateMap, 2);
    S1 = squeeze(stateMap(d1,:,:)); 
    S2 = squeeze(stateMap(d2,:,:));
    U1 = squeeze(uncertainty_Map(d1,:,:));
    U2 = squeeze(uncertainty_Map(d2,:,:));
    T1 = squeeze(uncertainty_Map(d1+3,:,:)); % Timestamp for drone 1
    T2 = squeeze(uncertainty_Map(d2+3,:,:)); % Timestamp for drone 2
    
    %  Process each cell with uncertainty-weighted fusion
    for i = 1:N
        for j = 1:N
            % Skip if neither drone has seen this cell
            if ~seen1(i,j) && ~seen2(i,j)
                continue;
            end
            
            % Check if information was already shared in this fusion step
            % If both have the same timestamp from this step, they already fused
            if seen1(i,j) && seen2(i,j) && T1(i,j) == 0 && T2(i,j) == 0
                % Already fused in this communication step - skip to avoid double counting
                continue;
            end
            
            if seen1(i,j) && seen2(i,j) && (uncertainty_Map(d1+3,i,j) ~= uncertainty_Map(d2+3,i,j) || uncertainty_Map(d1,i,j) ~=uncertainty_Map(d2,i,j))
                % Both drones have data for this cell - perform uncertainty-weighted fusion
                w1 = 1 / (U1(i,j) + sigma_velocity(d1) + eps);
                w2 = 1 / (U2(i,j) + sigma_velocity(d2) + eps);
                
                % Fuse based on confidence (lower uncertainty = higher weight)
                fused_state = (w1 * S1(i,j) + w2 * S2(i,j)) / (w1 + w2);
                fused_uncertainty = 1 / (w1 + w2);
                
                % Update both drones with fused values
                stateMap(d1,i,j) = fused_state;
                stateMap(d2,i,j) = fused_state;
                uncertainty_Map(d1,i,j) = fused_uncertainty;
                uncertainty_Map(d2,i,j) = fused_uncertainty;
                uncertainty_Map(d1+3,i,j) = step; % Mark as fused in this step
                uncertainty_Map(d2+3,i,j) = step; % Mark as fused in this step
                merge_stepd1 = step;
                merge_stepd2 = step;
            elseif seen1(i,j) && ~seen2(i,j) || (seen2(i,j) && U1(i,j) < U2(i,j))
                % Only drone 1 has seen this cell - share with drone 2 or
                % is more secure
                    stateMap(d2,i,j) = S1(i,j);
                    uncertainty_Map(d2,i,j) = U1(i,j);
                    uncertainty_Map(d2+3,i,j) = uncertainty_Map(d1+3,i,j);
                    merge_stepd2 = step;
            elseif seen2(i,j) && ~seen1(i,j) || (seen1(i,j) && U2(i,j) < U1(i,j))
                % Only drone 2 has seen this cell - share with drone 1 or
                % is more secure
                    stateMap(d1,i,j) = S2(i,j);
                    uncertainty_Map(d1,i,j) = U2(i,j);
                    uncertainty_Map(d1+3,i,j) = uncertainty_Map(d2+3,i,j);
                    merge_stepd1 = step;
                    
                
            end
        end
    end
end