function [direction,vel] = directedMovement(Pos, target)

    v = target - Pos;                 % displacement vector
    vel = norm(v);
    direction = v / max(norm(v),1);          % normalize to unit length

end
