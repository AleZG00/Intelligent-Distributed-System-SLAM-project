function [pathR, pathC, ok] = improved_astar_with_safety(safetyMap2, startRC, goalRC)
    % A* algorithm to find the path
    
    ok = false;
    [rows, cols] = size(safetyMap2);
    
    if safetyMap2(startRC(1), startRC(2)) == Inf
        fprintf('Start not accessible in safety map\n');
        pathR = []; pathC = []; 
        return;
    end
    if safetyMap2(goalRC(1), goalRC(2)) == Inf
        fprintf('Goal not accessible in safety map\n');
        pathR = []; pathC = []; 
        return;
    end
    
    dirs = [-1 -1; -1 0; -1 1; 0 -1; 0 1; 1 -1; 1 0; 1 1];
    moveCost = [sqrt(2), 1, sqrt(2), 1, 1, sqrt(2), 1, sqrt(2)];
    
    g = Inf(rows, cols);
    f = Inf(rows, cols);
    visited = false(rows, cols);
    parent = zeros(rows, cols, 2, 'int32');
    
    sr = startRC(1); sc = startRC(2);
    gr = goalRC(1); gc = goalRC(2);
    
    g(sr,sc) = 0;
    f(sr,sc) = heuristic(sr, sc, gr, gc);
    openList = [f(sr,sc), sr, sc];
    
    maxSteps = rows * cols;
    step = 0;
    
    while ~isempty(openList) && step < maxSteps
        step = step + 1;
        
        [~, idx] = min(openList(:,1));
        current = openList(idx, 2:3);
        openList(idx, :) = [];
        cr = current(1); cc = current(2);
        
        if visited(cr, cc), continue; end
        visited(cr, cc) = true;
        
        if cr == gr && cc == gc
            [pathR, pathC] = reconstruct_path(parent, sr, sc, gr, gc);
            ok = true;
            return;
        end
        
        for d = 1:size(dirs, 1)
            nr = cr + dirs(d, 1);
            nc = cc + dirs(d, 2);
            
            if nr < 1 || nr > rows || nc < 1 || nc > cols
                continue;
            end
            
            if safetyMap2(nr, nc) == Inf
                continue;
            end
            
            if visited(nr, nc)
                continue;
            end
            
            if dirs(d, 1) ~= 0 && dirs(d, 2) ~= 0
                if safetyMap2(cr, nc) == Inf || safetyMap2(nr, cc) == Inf
                    continue;
                end
            end
            
            tentative_g = g(cr, cc) + moveCost(d);
            
            if tentative_g < g(nr, nc)
                g(nr, nc) = tentative_g;
                parent(nr, nc, 1) = cr;
                parent(nr, nc, 2) = cc;
                f(nr, nc) = tentative_g + heuristic(nr, nc, gr, gc);
                
                inOpenList = false;
                for i = 1:size(openList, 1)
                    if openList(i, 2) == nr && openList(i, 3) == nc
                        openList(i, 1) = f(nr, nc);
                        inOpenList = true;
                        break;
                    end
                end
                
                if ~inOpenList
                    openList(end+1, :) = [f(nr, nc), nr, nc];
                end
            end
        end
    end
    
    fprintf('A* failed after %d steps\n', step);
    pathR = []; pathC = [];
end