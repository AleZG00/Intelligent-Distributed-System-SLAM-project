function [costMap, obstacleMask] = crea_cost_map(typeMap, victimRow, victimCol)
    % Create the cost map for navigation
    
    M = size(typeMap,1);
    N = size(typeMap,2);
    
    costMap = ones(M,N);
    obstacleMask = (typeMap ~= 0);
    
    obstacleMask(victimRow, victimCol) = false;
    
    victim_water_neighbors = false(M,N);
    for dr = -1:1
        for dc = -1:1
            if dr == 0 && dc == 0, continue; end
            nr = victimRow + dr;
            nc = victimCol + dc;
            if nr >= 1 && nr <= N && nc >= 1 && nc <= N
                if typeMap(nr, nc) == 0
                    victim_water_neighbors(nr, nc) = true;
                    obstacleMask(nr, nc) = false;
                end
            end
        end
    end

    costMap(obstacleMask) = Inf;

    verifica_accessibilita_vittima(costMap, typeMap, victimRow, victimCol);
end