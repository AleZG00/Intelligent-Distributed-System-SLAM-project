function [boatPos, boatRow, boatCol, start] = posiziona_barca_sicura(costMap, idMap, victimRow, victimCol)
    % Serch a safe position for the boat
    
    fprintf('\nSAFE BOAT PLACEMENT \n');
    M = size(costMap,1);
    N = size(costMap,2);
    targetCoastID = 1;
    
    % Masks to identify different areas
    seaMask = (costMap == 1);
    targetLandMask = (idMap == targetCoastID);
    
    % Identify the cliff (target coast)
    scoglieraMask = targetLandMask;
    
    % Identify dangerous obstacles (everything that is not sea and not the target coast)
    % Consider as dangerous obstacles only areas with Inf cost that are not cliff
    obstacleMask = (costMap == Inf) & ~scoglieraMask;
    
    % Find coastal positions (sea bordering land)
    kernel = ones(3,3); kernel(5) = 0;
    neighborTargetCount = conv2(double(targetLandMask), kernel, 'same');
    coastCandidates = seaMask & (neighborTargetCount > 0);
    
    % Calculate distance only from dangerous obstacles (not from cliff)
    obstacleDistances = bwdist(obstacleMask);
    
    % Safety parameters
    minSafeDistanceFromObstacles = 8;  % Minimum distance from dangerous obstacles
    
    % Create mask (51-950)
    validRowsMask = false(M, N);
    validRowsMask(51:end-50, :) = true;  
    
    % Search for safe positions (only in valid rows)
    safeCoastPositions = coastCandidates & (obstacleDistances >= minSafeDistanceFromObstacles) & validRowsMask;
    
    if nnz(safeCoastPositions) == 0
        fprintf('No safe position found, relaxing criteria...\n');
        minSafeDistanceFromObstacles = 4;
        safeCoastPositions = coastCandidates & (obstacleDistances >= minSafeDistanceFromObstacles) & validRowsMask;
    end
    
    if nnz(safeCoastPositions) == 0
        fprintf('Warning: using positions close to dangerous obstacles...\n');
        safeCoastPositions = coastCandidates & validRowsMask;
    end
    
    [safeRows, safeCols] = find(safeCoastPositions);
    
    if isempty(safeRows)
        error('No position found for the boat!');
    end
    
    fprintf('Found %d candidate positions for the boat\n', length(safeRows));
    
    % Improved scoring system
    scores = zeros(length(safeRows), 1);
    
    for i = 1:length(safeRows)
        r = safeRows(i);
        c = safeCols(i);
        
        % Safety score (50% weight)
        obstacleScore = obstacleDistances(r, c) / 10;  % Normalized
        
        % Distance from victim score (30% weight)
        distToVictim = sqrt((r - victimRow)^2 + (c - victimCol)^2);
        victimScore = 1 / (1 + abs(distToVictim - 300) / 100);  % Normalized
        
        % Accessibility score (20% weight)
        localArea = costMap(max(1,r-5):min(M,r+5), max(1,c-5):min(N,c+5));
        accessibilityScore = nnz(localArea == 1) / numel(localArea);
        
        % Cliff proximity score (bonus)
        coastDistance = neighborTargetCount(r, c);  % Number of land neighbors
        coastScore = min(coastDistance / 8, 1);     % Normalized
        
        scores(i) = obstacleScore * 0.5 + victimScore * 0.3 + accessibilityScore * 0.2 + coastScore * 0.1;
    end
    
    % Optimal position selection
    [~, bestIdx] = max(scores);
    boatRow = safeRows(bestIdx);
    boatCol = safeCols(bestIdx);
    boatPos = [boatCol, boatRow];
    start = [boatRow, boatCol];
    
    % Calculate actual distance from dangerous obstacles
    distanzaOstacoli = obstacleDistances(boatRow, boatCol);
    distanzaVittima = sqrt((boatRow - victimRow)^2 + (boatCol - victimCol)^2);
    
    fprintf('Boat placed at: (%d, %d)\n', boatCol, boatRow);
    fprintf('Distance from dangerous obstacles: %.1f px\n', distanzaOstacoli);
    fprintf('Distance from victim: %.1f px\n', distanzaVittima);
    
    % Safety evaluation
    if distanzaOstacoli >= 8
        fprintf('✅ VERY SAFE position\n\n');
    elseif distanzaOstacoli >= 4
        fprintf('✅ Safe position\n\n');
    else
        fprintf('⚠️  Risky position - close to dangerous obstacles\n\n');
    end
end