function safetyMap = crea_safety_map_typeMap(rounded_state_map, boatPos, victimPos, safetyDistance, victimSafetyDistance)
    % Create safety map with safety buffer
    
    [rows, cols] = size(rounded_state_map);
    safetyMap = ones(rows, cols);
    
    victimRow = victimPos(1);
    victimCol = victimPos(2);
    boatRow = boatPos(2);
    boatCol = boatPos(1);

    fprintf('Creating safety map WITH BUFFER ON rounded_state_map:\n');
    fprintf('  Safety buffer: %d px\n', safetyDistance);
    fprintf('  Victim safe area: %d px\n', victimSafetyDistance);
    
    cliffObstacles = (rounded_state_map == 1);
    dangerousObstacles = (rounded_state_map >= 2 & rounded_state_map <= 4);
    
    fprintf('  Cliff (without buffer): %d pixels\n', nnz(cliffObstacles));
    fprintf('  Dangerous obstacles (with buffer): %d pixels\n', nnz(dangerousObstacles));
    
    if safetyDistance > 0
        se = strel('disk', safetyDistance);
        prohibitedZones = imdilate(dangerousObstacles, se);
    else
        prohibitedZones = dangerousObstacles;
    end
    
    fprintf('  Prohibited zones after buffer: %d pixels\n', nnz(prohibitedZones));
    
    cliffZones = cliffObstacles;
    fprintf('  Cliff zones (direct obstacle): %d pixels\n', nnz(cliffZones));
    
    allProhibitedZones = prohibitedZones | cliffZones;
    fprintf('  Total prohibited zones: %d pixels\n', nnz(allProhibitedZones));
    
    % VICTIM SAFE AREA (as before)
    if victimSafetyDistance > 0
        victimCells = (rounded_state_map > 5);
        se_victim = strel('disk', victimSafetyDistance);
        victimSafeArea = imdilate(victimCells, se_victim);

        bufferZonesInSafeArea = allProhibitedZones & victimSafeArea;  % Use allProhibitedZones
        allProhibitedZones(bufferZonesInSafeArea) = false;

        fprintf('  Prohibited zones after victim area: %d pixels\n', nnz(allProhibitedZones));
        fprintf('  Victim safe area: %d pixels\n', nnz(victimSafeArea));
    end
    
    % BOAT SAFE AREA (NEW - CORRECTED)
    if victimSafetyDistance > 0
        boatCells = false(rows, cols);
        boatCells(boatRow, boatCol) = true;
        se_boat = strel('disk', victimSafetyDistance);
        boatSafeArea = imdilate(boatCells, se_boat);

        bufferZonesInBoatArea = allProhibitedZones & boatSafeArea;  % Use allProhibitedZones instead of prohibitedZones
        allProhibitedZones(bufferZonesInBoatArea) = false;

        fprintf('  Prohibited zones after boat area: %d pixels\n', nnz(allProhibitedZones));
        fprintf('  Boat safe area: %d pixels\n', nnz(boatSafeArea));
    end
    
    safetyMap(allProhibitedZones) = Inf;
    safetyMap(victimRow, victimCol) = 1;
    
    fprintf('  Final Safety Map:\n');
    fprintf('    - Accessible cells: %d\n', nnz(safetyMap == 1));
    fprintf('    - Blocked cells: %d\n', nnz(safetyMap == Inf));
    fprintf('    - Of which cliff: %d\n', nnz(cliffZones & (safetyMap == Inf)));
    fprintf('    - Of which obstacle buffer: %d\n', nnz(prohibitedZones & (safetyMap == Inf)));
    fprintf('    - Victim accessible: %d\n', safetyMap(victimRow, victimCol) == 1);
end