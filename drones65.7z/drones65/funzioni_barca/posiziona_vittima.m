function [typeMap, idMap_boat, victimPos, victimRow, victimCol] = posiziona_vittima(typeMap, idMap_boat, types)
    % Places the victim in water with safety criteria
    
    fprintf('\nVICTIM PLACEMENT IN WATER (AWAY FROM CLIFF) \n');
    N = size(typeMap, 1);
    
    
    % Create mask of valid inner region
    validRowsMask = false(N, N);
    validRowsMask(1:end, 1:end) = true;
    
    % Create a water mask that keeps shape N x N
    waterMask = (typeMap == 0);
    
    % Apply both masks properly
    waterMask = waterMask & validRowsMask;


    % Create a distance map from the cliff
    cliffMask = (typeMap == types(1));
    cliffDistance = bwdist(cliffMask);

    % Create a map that counts water neighbors for each cell
    kernel = ones(3,3); 
    kernel(2,2) = 0;
    waterNeighborsCount = conv2(double(waterMask), kernel, 'same');

    % Create a map that indicates if a water cell has at least 1 obstacle neighbor
    % EXCLUDE cliff from obstacles for neighbors
    otherObstaclesMask = (typeMap >= types(2) & typeMap <= types(4)); % Only barrier, buoy, reef
    obstacleNeighbors = conv2(double(otherObstaclesMask), kernel, 'same') > 0;

    % Criteria for victim position:
    % 1. Must be in water (typeMap == 0)
    % 2. Must be at least 10 pixels away from cliff
    % 3. Must have at least 4 water neighbors (including diagonals)
    % 4. At least 1 of its water neighbors must border an obstacle (NOT cliff)
    minCliffDistance = 10;
    validVictimMask = waterMask & ...
                      (cliffDistance >= minCliffDistance) & ...
                      (waterNeighborsCount >= 4) & ...
                      obstacleNeighbors;

    if ~any(validVictimMask(:))
        fprintf('No perfect position found, relaxing criteria...\n');
        % Relax criteria: reduce minimum distance from cliff
        minCliffDistance = 5;
        validVictimMask = waterMask & ...
                          (cliffDistance >= minCliffDistance) & ...
                          (waterNeighborsCount >= 3) & ...
                          obstacleNeighbors;
        
        if ~any(validVictimMask(:))
            fprintf('No valid position found, using minimum criteria...\n');
            % Minimum criteria: in water with distance from cliff and at least 1 obstacle neighbor
            minCliffDistance = 3;
            validVictimMask = waterMask & ...
                              (cliffDistance >= minCliffDistance) & ...
                              obstacleNeighbors;
        end
    end

    if ~any(validVictimMask(:))
        error('No valid position found for the victim!');
    end

    % Select a random position from the valid ones
    validIdx = find(validVictimMask);
    victimIdx = validIdx(randi(numel(validIdx)));
    [victimRow, victimCol] = ind2sub([N,N], victimIdx);

    % Mark the victim on the map (type 50 for victim)
    typeMap(victimRow, victimCol) = 50;
    idMap_boat(victimRow, victimCol) = 50;
    victimPos = [victimCol, victimRow];

    fprintf('✓ Victim placed in WATER at: (%d, %d)\n', victimCol, victimRow);
    fprintf('  Cell type: %d (0=water, 50=victim)\n', typeMap(victimRow, victimCol));
    fprintf('  Minimum distance from cliff: %.1f pixels\n', cliffDistance(victimRow, victimCol));
    fprintf('  Total water neighbors: %d/8\n', waterNeighborsCount(victimRow, victimCol));

    % Debug: show victim's neighbors
    fprintf('\nVictim neighbors analysis:\n');
    water_count = 0;
    obstacle_adjacent_count = 0;
    cliff_adjacent_count = 0;

    for dr = -1:1
        for dc = -1:1
            if dr == 0 && dc == 0, continue; end
            nr = victimRow + dr;
            nc = victimCol + dc;
            if nr >= 1 && nr <= N && nc >= 1 && nc <= N
                cell_type = typeMap(nr, nc);
                fprintf('  Neighbor (%d,%d): type=%d', nc, nr, cell_type);
                
                if cell_type == 0
                    water_count = water_count + 1;
                    fprintf(' [WATER]');
                    % Check if this water neighbor borders an obstacle (NOT cliff)
                    has_obstacle_neighbor = false;
                    for dr2 = -1:1
                        for dc2 = -1:1
                            if dr2 == 0 && dc2 == 0, continue; end
                            nr2 = nr + dr2;
                            nc2 = nc + dc2;
                            if nr2 >= 1 && nr2 <= N && nc2 >= 1 && nc2 <= N
                                neighbor_type = typeMap(nr2, nc2);
                                if neighbor_type >= types(2) && neighbor_type <= types(4) % Obstacle (NOT cliff)
                                    obstacle_adjacent_count = obstacle_adjacent_count + 1;
                                    fprintf(' -> Borders obstacle type=%d at (%d,%d)', neighbor_type, nc2, nr2);
                                    has_obstacle_neighbor = true;
                                    break;
                                elseif neighbor_type == types(1) % Cliff
                                    cliff_adjacent_count = cliff_adjacent_count + 1;
                                    fprintf(' -> Borders CLIFF at (%d,%d)', nc2, nr2);
                                end
                            end
                        end
                        if has_obstacle_neighbor, break; end
                    end
                elseif cell_type == types(1)
                    fprintf(' [CLIFF - NOT ALLOWED]');
                else
                    fprintf(' [OBSTACLE type=%d]', cell_type);
                end
                fprintf('\n');
            end
        end
    end

    fprintf('\n✓ Victim position summary:\n');
    fprintf('  - Position: (%d, %d) in WATER\n', victimCol, victimRow);
    fprintf('  - Distance from cliff: %.1f pixels\n', cliffDistance(victimRow, victimCol));
    fprintf('  - Water neighbors: %d/8\n', water_count);
    fprintf('  - Water neighbors bordering obstacles (NOT cliff): %d\n', obstacle_adjacent_count);
    fprintf('  - Neighbors bordering cliff: %d\n', cliff_adjacent_count);

    % Safety checks
    if typeMap(victimRow, victimCol) == types(1)
        error('ERROR: Victim was placed on cliff!');
    end

    if cliffDistance(victimRow, victimCol) < minCliffDistance
        error('ERROR: Victim is too close to cliff!');
    end

    fprintf('✓ Check: Victim NOT on cliff and at safe distance\n');
end