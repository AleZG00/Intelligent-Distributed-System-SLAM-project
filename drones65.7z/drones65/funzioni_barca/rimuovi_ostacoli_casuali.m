function idMap_boat = rimuovi_ostacoli_casuali(idMap_boat, ID_known_perc,types)
% Randomly removes some obstacles
    
% We keep only a % of obstacles (except cliff and victim)
nIds = max(idMap_boat(:));

% List all "droppable" IDs (everything except 1 and 5)
dropableIds = setdiff(1:nIds, [types(1), 50]);

% Decide how many ID to keep
keepFrac = ID_known_perc;
nDropable = numel(dropableIds);
nKeepDropable = round(keepFrac * nDropable);

% Randomly pick that many from the droppable pool
keepDropable = dropableIds(randperm(nDropable, nKeepDropable));

% Final "keep" list is {1,5} plus those randomly chosen
keepIds = sort([2, 50, keepDropable]);

% Zero out any cell whose ID is nonzero but not in keepIds
maskDrop = idMap_boat > 0 & ~ismember(idMap_boat, keepIds);
idMap_boat(maskDrop) = 0;

end