function visualizza_risultati_finali(typeMap, victimPos, boatPos, pathRows, pathCols, success)
    % Display final results
    
    if success
        pathCoords = [pathCols, pathRows];
        path_len = sum(sqrt(sum(diff([pathRows, pathCols]).^2,2)));
    else
        pathCoords = [];
    end
    

    % TypeMap
    figure;
    imagesc(typeMap); 
    axis equal tight; 
    set(gca, 'YDir', 'normal'); 
    hold on;

    plot(victimPos(1), victimPos(2), 'k*', 'MarkerSize', 20, 'LineWidth', 3, 'DisplayName', 'Victim');
    plot(boatPos(1), boatPos(2), 'bo', 'MarkerSize', 15, 'LineWidth', 3, 'MarkerFaceColor', 'blue', 'DisplayName', 'Boat');

    if success
        plot(pathCoords(:,1), pathCoords(:,2), 'r-', 'LineWidth', 2, 'DisplayName', 'Path');
        title(sprintf('Boat Path → Victim\nLength: %.1f px (%d steps)', path_len, size(pathRows,1)));
    else
        title('Path not found');
    end

    legend('Location', 'bestoutside');
    xlabel('Column (px)');
    ylabel('Row (px)');
    grid on; set(gca, 'GridAlpha', 0.3);
    exportgraphics(gcf,'immagini/15_Boat_Path_to_Victim.pdf','ContentType','vector')
end