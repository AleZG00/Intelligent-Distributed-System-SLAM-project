function verifica_accessibilita_vittima(costMap, typeMap, victimRow, victimCol)
    % Check that the victim is accessible
    
    % Debug: show what we receive
    fprintf('\nDEBUG - victimRow: %4d\nDEBUG - victimCol: %4d\n', victimRow, victimCol);
    
    % Use the first element if they are arrays
    vr = victimRow(1);
    vc = victimCol(1);
    
    fprintf('\nCheck victim in costMap:\n');
    fprintf('  typeMap(victim): %d\n', typeMap(vr, vc));
    fprintf('  costMap(victim): %f\n', costMap(vr, vc));
    fprintf('  Victim is reachable: %d\n', costMap(vr, vc) == 1);

    accessible_neighbors = 0;
    N = size(costMap, 1);
    for dr = -1:1
        for dc = -1:1
            if dr == 0 && dc == 0, continue; end
            nr = vr + dr;
            nc = vc + dc;
            if nr >= 1 && nr <= N && nc >= 1 && nc <= N
                if costMap(nr, nc) == 1
                    accessible_neighbors = accessible_neighbors + 1;
                end
            end
        end
    end
    fprintf('  Accessible neighbors of victim: %d\n', accessible_neighbors);

    if costMap(vr, vc) == Inf || accessible_neighbors == 0
        error('ERROR: Victim is not reachable in base costMap!');
    end
end