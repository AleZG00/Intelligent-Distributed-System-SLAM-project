function [costMap_Barca, obstacleMask_Barca] = crea_cost_map_Barca(typeMap, victimRow, victimCol)
    % Create the cost map for navigation
    
    M = size(typeMap,1);
    N = size(typeMap,2);
    
    costMap_Barca = ones(M,N);
    obstacleMask_Barca = (typeMap ~= 0);
    
    obstacleMask_Barca(victimRow, victimCol) = false;
    
    victim_water_neighbors = false(M,N);
    for dr = -1:1
        for dc = -1:1
            if dr == 0 && dc == 0, continue; end
            nr = victimRow + dr;
            nc = victimCol + dc;
            if nr >= 1 && nr <= N && nc >= 1 && nc <= N
                if typeMap(nr, nc) == 0
                    victim_water_neighbors(nr, nc) = true;
                    obstacleMask_Barca(nr, nc) = false;
                end
            end
        end
    end

    costMap_Barca(obstacleMask_Barca) = Inf;

end