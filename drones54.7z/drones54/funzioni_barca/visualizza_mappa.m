function visualizza_mappa(typeMap, idMap_boat, victimPos)
    % Display the initial map
    
    figure;
    subplot(1,2,1);
    imagesc(typeMap); axis equal tight;
    hold on;
    plot(victimPos(1), victimPos(2), 'k*','Color', [0.9 0.9 0.9], 'MarkerSize', 10, 'LineWidth', 2);  
    title('0=water,1=cliff,2=barrier,3=buoy,4=reef,5=victim');
    set(gca, 'YDir', 'normal');
    colorbar('Ticks',[0 1 2 3 4], 'TickLabels', {'0:Water', '1:Cliff', '2:Barrier', '3:Buoy', '4:Reef'});
    clim([0 4]);

    subplot(1,2,2);
    imagesc(idMap_boat); axis equal tight;
    hold on;
    plot(victimPos(1), victimPos(2), 'k*','Color', [0.9 0.9 0.9], 'MarkerSize', 10, 'LineWidth', 2);
    title('idMap_boat (yellow = labeled obstacle cells,white = Victim in water)', 'Interpreter', 'none');
    set(gca, 'YDir', 'normal');
    colorbar;
end