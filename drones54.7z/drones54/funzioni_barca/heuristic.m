function h = heuristic(r1, c1, r2, c2)
    % Heuristic function for A*
    h = sqrt((r1 - r2)^2 + (c1 - c2)^2);
end