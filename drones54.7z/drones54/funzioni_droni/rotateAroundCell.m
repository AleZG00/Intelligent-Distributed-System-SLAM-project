function M_rot = rotateAroundCell(M, angle, pivotRow, pivotCol)
    [rows, cols] = size(M);

    % shift pivot to matrix center
    rowShift = round(rows/2 - pivotRow);
    colShift = round(cols/2 - pivotCol);
    M_shift = circshift(M, [rowShift, colShift]);

    % Check if angle is multiple of 90°
    if mod(angle,90) == 0
        k = mod(angle/90,4);           % number of 90° rotations
        M_rot = rot90(M_shift, k);     % perfect rotation, no interpolation
    else
        % arbitrary angle: use imrotate with nearest neighbor
        M_rot = imrotate(M_shift, angle, 'nearest', 'crop');
    end

    % shift pivot back
    M_rot = circshift(M_rot, [-rowShift, -colShift]);
end
