function direction = directedMovement(Pos, target)

    v = target - Pos;                 % displacement vector
    direction = v / max(norm(v),1);          % normalize to unit length

end
