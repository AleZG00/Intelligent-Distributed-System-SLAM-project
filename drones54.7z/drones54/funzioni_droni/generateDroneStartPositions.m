function startPos = generateDroneStartPositions(victimPos, numDrones, N, minDist)
% generateDroneStartPositions  Random start positions at least minDist from victim
%
% Inputs:
%   victimPos  – 1×2 [row, col] of the victim
%   numDrones  – number of drones to place
%   N          – map size (assumes valid rows/cols ∈ [1..N])
%   minDist    – minimum Euclidean distance from victim
%
% Output:
%   startPos   – numDrones×2 array of [row, col] start positions

startPos = zeros(numDrones, 2);
for i = 1:numDrones
    while true
        % sample uniformly in [1, N]
        row = (N-21)*rand + 20;
        col = (N-21)*rand + 20;
        if norm([row, col] - victimPos) >= minDist
            startPos(i,:) = [row, col];
            break;
        end
    end
end
end
