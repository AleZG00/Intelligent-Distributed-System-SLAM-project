clc;
close all;
clear;

% ADD FOLDER TO MATLAB PATH
addpath('funzioni_droni');
addpath('funzioni_barca');

% REMOVE LATEX INTERPRETATION OR USE 'none' FOR TITLES
set(0,'defaulttextinterpreter','none')
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
set(0,'DefaultFigureWindowStyle','docked');
set(0,'defaultAxesFontSize',  22)
set(0,'DefaultLegendFontSize',  20)

visu = 1; % 1 = visualize map, 0 = no visualization
visualize_in_real_time = 1;

ID_known_perc = 0.55; % How many ID's are known (How many remarks has the map in %)
sigma_radar = [1, 1, 1];  % The higher the value the worst the drone can see
sigma_velocity = [2, 2, 2];
gamma = 0.3; % variable that controls how much the filter trusts less measurements based on the uncertainty in the position
FinishRandomStep = 550; % How long the drones move randomly before exploring new areas
minDist = 450; % Minimum distance from the victim

% Parameters
maxSteps = 1500; % Maximum duration of the simulation
connectionRange = 70;
viewRadius = 70; % Area of the drone visual range (in px)
true_angle = [0, -90, 180];% round(rand*360), round(rand*360)];
dist = [0 0; 0 20; 0 -20]; % Drones 2 and 3 setup respect to drone 1
wait_iterations = 10; % how much time drone 1 gives the other drones to get in formation
count = 0; % Timer for drone 1 so it waits the other drones get in formation
min_certainty = 0.45; % how uncertain the drones can be about if they found the target
drones_vel = 10; % velocity of the drones in km/h

p_init = 1;% initial uncertainty, drones start in a position with almost no uncertainty  
P = diag([p_init, p_init, p_init, p_init, p_init, p_init]); % Covariance matrix init.

%% Map creation
fprintf('MAP CREATION \n');
[typeMap, idMap, ~] = crea_mappa_base();
idMap_boat = idMap;

types = [2 3 4 5]; 

%% Victim positioning
[typeMap, idMap_boat, victimPos, victimRow, victimCol] = posiziona_vittima(typeMap, idMap_boat, types);

if ~exist('immagini', 'dir')
    mkdir('immagini')
end

%% Random Obstacles Removal
idMap_boat = rimuovi_ostacoli_casuali(idMap_boat, ID_known_perc,types);
idMap= rimuovi_ostacoli_casuali(idMap_boat, ID_known_perc,types);
figure
    subplot(1,2,1);
    imagesc(idMap); axis equal tight;
    hold on;
    plot(victimPos(1), victimPos(2), 'k*','Color', [0.9 0.9 0.9], 'MarkerSize', 10, 'LineWidth', 2);
    title('Map with all labeled IDs');
    set(gca, 'YDir', 'normal');


idMap_flat = idMap(:);                        % flatten matrix into vector
[~, firstIdx] = unique(idMap_flat, 'first');  % find first occurrence indices
mask = true(size(idMap_flat));                % initialize mask as all true
mask(firstIdx) = false;                       % mark first occurrences as NOT duplicates
idMap_flat(mask) = 0;                         % replace duplicates with 0
idMap = reshape(idMap_flat, size(idMap));

    subplot(1,2,2);
    imagesc(typeMap); axis equal tight;
    hold on;
    plot(victimPos(1), victimPos(2), 'k*','Color', [0.9 0.9 0.9], 'MarkerSize', 10, 'LineWidth', 2);  
    title('Map with all obstacles, the white star is the target');
    set(gca, 'YDir', 'normal');
    % colorbar('Ticks',[0 1 2 3 4], 'TickLabels', {'0:Water', '1:Cliff', '2:Barrier', '3:Buoy', '4:Reef'});
    clim([0 5]);
exportgraphics(gcf,'immagini/2_Map_with_reduced_IDs.pdf','ContentType','vector')


%% Cost-Map Creation
[costMap, obstacleMask] = crea_cost_map(typeMap, victimRow, victimCol);
for i =-1:1
    for j = -1:1
        typeMap(victimRow+j, victimCol+i) = 50;
    end
end

%% Drones movement 
% PARAMETERS
N = 1000;                            
nextID  = 1;

% To avoid that the drones find at first step the objective we ashure the
% drones start at at least 500 m from the victim
starts = generateDroneStartPositions(victimPos, 3, N, minDist);
starting_pos_drone1 = starts(1,:);
starting_pos_drone2 = starts(2,:);
starting_pos_drone3 = starts(3,:);

% Initialize drone position (true and believed)
dronePos = [starting_pos_drone1; starting_pos_drone2; starting_pos_drone3];
Bpos = dronePos; % At the beginning they match

% Helper variables init
stateMap = zeros(3, N, N); % Initialize empty maps for each drone (each starts unaware of obstacles)
xk = [starting_pos_drone1(1); starting_pos_drone1(2); starting_pos_drone2(1); starting_pos_drone2(2); starting_pos_drone3(1); starting_pos_drone3(2)];
v = [0; 0; 0; 0; 0; 0];
avgUncertaintyHistory = zeros(3, maxSteps);  
Pos_error = zeros(3, maxSteps);
actual_movement = [0,0];
uncertain_steps = zeros(3,1);

%Flags
victimFound = false;
finish = false;
founder = 0;
ok = [false false false];
ok23 = [false false];
ok32 = false;
AtVictim = false;

finalStep = maxSteps;
theta_deg = [0, 0, 0]; % CCW rotation to allign map 1 to 2, 2 to 3, and 1 to 3

% Plot of the true map
figure;
hold on;
imagesc(typeMap);
plot(victimPos(1), victimPos(2), 'k*','MarkerSize', 12, 'LineWidth', 2);
axis equal tight;
title('Full map with true positions')
colors = ['r', 'g', 'b'];
clim([0 5]);
for d = 1:3
    hPoints(d) = plot(nan, nan, 'o', 'Color', colors(d), 'MarkerSize', 6, 'LineWidth', 1.5);
end
exportgraphics(gcf,'immagini/SpecialCase.pdf','ContentType','vector')
%% --- Fusion state for every cell ---
P0      = 1;                           % initial variance for every cell (uncertainty on each cell)             
uncertainty_Map   = repmat( P0, [3, N, N] );   

Previous_dir(d,2)=0;
Previous_dir(:,1) = 1; % Starting direction of the drones
merge_step = zeros(1,3);
localIdMap = zeros(3, N, N);

%% Real time maps setup

%— set up local‐map figure —
fig1 = figure; clf;
for d = 1:3
    axMap(d) = subplot(1,3,d);           %# axes handles
    hold on;
    % initial blank image
    hImg(d) = imagesc( squeeze(stateMap(d,:,:)) );
    set(axMap(d), 'YDir','normal', 'NextPlot','add');
    hPoint(d) = plot(NaN, NaN, 'o', 'Color', colors(d), ...
                     'MarkerSize',6, 'LineWidth',1.5);
    hPoints2(d) = plot(nan, nan, 'o', 'Color', 'k', 'MarkerSize', 6, 'LineWidth', 1.5);
    % hPoints(d) = plot(nan, nan, 'o', 'Color', 'k', 'MarkerSize', 6, 'LineWidth', 1.5);
    title(axMap(d), sprintf('Drone %d Map', d));
    axis(axMap(d), 'equal','tight');
    colorbar('Ticks',[0 1 2 3 4]);
    clim([0 5]);
end
drawnow;

%— set up uncertainty figure —
fig2 = figure; clf;
for d = 1:3
    axUnc(d) = subplot(1,3,d);
    hUnc(d)  = imagesc( squeeze(uncertainty_Map(d,:,:)) );
    set(axUnc(d), 'YDir','normal');
    colorbar;
    clim([0 1]);
    title(axUnc(d), sprintf('Drone %d Uncertainty', d));
    axis('equal','tight');
end
drawnow;


% Figure for Position Error
figErr = figure; clf;
axErr = axes(figErr);
hold(axErr,'on')
for d = 1:3
    hErr(d) = plot(axErr,nan, nan, '-', 'Color', colors(d), 'LineWidth', 2);
end
grid on;
grid minor;
xlabel(axErr,'Step [#]');
ylabel(axErr,'Absolute Position Error [m]');
legend(axErr,{'Drone 1','Drone 2','Drone 3'}, 'Location','best');
ylim(axErr,[0,100])
title(axErr,'Position Error Over Time');

%% Boat Placement
[costMap_Barca, obstacleMask_Barca] = crea_cost_map_Barca(typeMap, victimRow, victimCol);
[typeMap_Barca, idMap_boat] = crea_mappa_base_Barca();
[boatPos, boatRow, boatCol, start] = posiziona_barca_sicura(costMap_Barca, idMap_boat, victimRow, victimCol);

%% Main loop
R_map_evolution = zeros(3,finalStep);
regrup_pos = [0,0];

% Main loop
for step = 1:maxSteps
    for d = 1:3
        if finish, continue; end


        % calculation to obtain the actual visibility range
        x = round(dronePos(d,1));
        y = round(dronePos(d,2));
        yrange = max(1, x-viewRadius):min(N, x+viewRadius);
        xrange = max(1, y-viewRadius):min(N, y+viewRadius);
        
        % drones distance to the targets
        dist_to_target = sqrt((Bpos(d,1)-regrup_pos(1)).^2+(Bpos(d,2)-regrup_pos(2)).^2);
        dist_to_target1 = sqrt((Bpos(1,1)-regrup_pos(1)).^2+(Bpos(1,2)-regrup_pos(2)).^2);
        dist_to_target2 = sqrt((Bpos(2,1)-regrup_pos(1)).^2+(Bpos(2,2)-regrup_pos(2)).^2);
        dist_to_target3 = sqrt((Bpos(3,1)-regrup_pos(1)).^2+(Bpos(3,2)-regrup_pos(2)).^2);

        % Move and update position
        if victimFound == false && step < FinishRandomStep % Random exploration
            exploreDir = chooseExplorationMove(Bpos(d,:), N, viewRadius,d,Previous_dir(d,:));
      
        elseif victimFound == false && step >= FinishRandomStep % Uncertain zones exploration
            % Extract 2D uncertainty map for drone d
            map2D = squeeze(uncertainty_Map(d,:,:));

            % Find the maximum uncertainty value
            maxVal = max(map2D(:));
            
            % Find all positions that have that maximum uncertainty
            [rows, cols] = find(map2D == maxVal);
            
            % Compute Euclidean distances from the drone's current position
            % Note: Bpos(d,:) = [x, y], but rows correspond to y and cols to x
            gp = Bpos(d,:);
        if true_angle(d) ~= 0
            gp(1) = Bpos(d,(2));
            gp(2) = Bpos(d,(1));        
            center = [(N+1)/2, (N+1)/2];   
            gp_rot = rotatePointAroundCenter(gp, center, true_angle(d));          
            gp = max(min(gp_rot, N), 1); 
            temp = gp(1);
            gp(1) = gp(2);
            gp(2) = temp;
        end
            distances = sqrt((cols - gp(1)).^2 + (rows - gp(2)).^2);
            
            % --- Select distances between 30 and 80 ---
            [~, selectedIdx] = min(distances);
            
            
            % Select the target coordinate [x, y]
            go_to_uncert = [cols(selectedIdx), rows(selectedIdx)];
            
            % Compute the direction vector toward that point
            exploreDir = directedMovement(gp, go_to_uncert);
             
            if true_angle(d) ~= 0 
            angle = -deg2rad(true_angle(d));    
            exploreDir = exploreDir*[cos(angle) ,-sin(angle); sin(angle) , cos(angle)]'; 
            end

        elseif dist_to_target1 <= 25 && dist_to_target2 <= 25 && dist_to_target3 <= 25 % Flag for when all drones are at the victim and go to the boat in formation
             AtVictim = true;
             regrup_pos = boatPos;
        elseif all(regrup_pos == boatPos) && d ~= 1 % Put drones 2 and 3 in formation
            exploreDir = directedMovement(Bpos(d,:),Bpos(1,:) + dist(d,:));
            count = count + 1;

        elseif dist_to_target1 <= 25 && all(regrup_pos == boatPos) % Exit of the main loop
            finish = true;

        elseif all(regrup_pos == boatPos) && d == 1 && count > wait_iterations % Path so drone 1 goes to the boat
            exploreDir = directedMovement(Bpos(d,:),regrup_pos)*2/3;

        elseif d == 1 && count < wait_iterations && victimFound == true && all(regrup_pos == boatPos) % Time drone 1 has to wait so other drones get in formation
            exploreDir = [0,0];

        elseif dist_to_target < 15 % If the a drone reaches the victim, wait the others
            exploreDir = [0,0];

        elseif dist_to_target >= 15 % Direction so other drones get to the victim
            exploreDir = directedMovement(Bpos(d,:),regrup_pos);
        end
        
        Previous_dir(d,:) = exploreDir; % save of the previous direction for maintaining the direction at eact step

        % Direction where the drone believes is moving
        believed_movement = exploreDir .*drones_vel ;

        % True direction influenced by drone intrinsic error and other
        % possible extern factors like wind or strikes with birds
        actual_movement = exploreDir .* (drones_vel + randn*sigma_velocity(d));  
        
        % Movement obtained at current step
        v = [0; 0; 0; 0; 0; 0];
        v(d*2 - 1) = believed_movement(1);
        v(d*2) = believed_movement(2);

        % Position update
        xk = xk + v;

        % Noise increase
        Qk = zeros(6);
        Qk(d*2 - 1, d*2 - 1) = sigma_velocity(d)^2;
        Qk(d*2, d*2) = sigma_velocity(d)^2;

        % Covariance update
        P = P + Qk;

        % True nwe position
        dronePos(d,1) =  max(min(dronePos(d,1) + actual_movement(1), N), 1); % Update the dronePos with the new movement for the next iteration 
        dronePos(d,2) =  max(min(dronePos(d,2) + actual_movement(2), N), 1);

        
        Bpos(d,1) = max(min(xk(d*2 - 1), N), 1); % Function that avoids the drone going out of the boundaries
        Bpos(d,2) = max(min(xk(d*2), N), 1);
        
        % Update of the position calculated from the model
        xk(d*2 - 1) = Bpos(d,1);
        xk(d*2) = Bpos(d,2);

       
        % calculation to obtain the believed visibility range so that in
        % the 1-D KF update the patch is placed where the drone thinks is
        % and if its nearer to the limit boundary doesn't attemp to
        % position values out of the map
        bx = round(Bpos(d,1));
        by = round(Bpos(d,2));
        byrange = max(1, bx-viewRadius):min(N, bx+viewRadius);
        bxrange = max(1, by-viewRadius):min(N, by+viewRadius);
        
        
        % Function that when an obstacle with an Id is seen the drone can
        % correct his position using EKF (Linearization on the
        % exteroceptive model)
        [P,xk,uncertain_steps(d,1)]= estimateDronePose2(P,d,dronePos(d,:),xk,idMap,sigma_radar,xrange, yrange,uncertain_steps(d,1),viewRadius);


        % Extract local map patch
        true_patch = typeMap(xrange, yrange); % What idealy the drone would see
        noisy_patch = double(true_patch) + (sigma_radar(d) * randn(size(true_patch))); % What it actually sees cause of uncertainty


        % perform a 1-D KF update for each newly observed cell, done to
        % reduce the uncertainty of each seen cell
        for dx = 1:numel(xrange)
            for dy = 1:numel(yrange)

                if (viewRadius + dronePos(d,2) >= N && viewRadius + Bpos(d,2) >= N)||(dronePos(d,2) - viewRadius <= 1 && Bpos(d,2) - viewRadius <= 1)
                    i = max(min(xrange(dx), N), 1);
                elseif xrange(dx)+round(Bpos(d,2)-dronePos(d,2)) <= N && xrange(dx) + round(Bpos(d,2)-dronePos(d,2)) >= 1 
                    i = xrange(dx)+round(Bpos(d,2)-dronePos(d,2));
                end

                if (viewRadius + dronePos(d,1) >= N && viewRadius + Bpos(d,1) >= N)||(dronePos(d,1) - viewRadius <= 1 && Bpos(d,1) - viewRadius <= 1)
                    j = max(min(yrange(dy), N), 1);
                elseif yrange(dy)+round(Bpos(d,1)-dronePos(d,1)) <= N && yrange(dy)+round(Bpos(d,1)-dronePos(d,1)) >= 1 
                    j = yrange(dy)+round(Bpos(d,1)-dronePos(d,1));
                end
                z = noisy_patch(dx,dy);          % measurement
                R = min(sigma_radar(d)^2 + (sigma_velocity(d)/2 * (1 + gamma * uncertain_steps(d,1)))^2,100) ; 
                % measurement variance for drone d, the more 
                % the drone goes by without having estimate it's
                % position from an ID the less it should be able to
                % positionate pixels in not certain positions
                

                p = [i j]; % Points rotation
                if true_angle(d) ~= 0
                    center = [(N+1)/2, (N+1)/2];  
                    p_rot = rotatePointAroundCenter(p, center, true_angle(d)); 
                    
                    if any(p_rot > N) || any(p_rot < 1) % if a point is out of boundaries discard it by putting them all in a dump position
                        p_rot = [1,N];
                    end
                    p = max(min(p_rot, N), 1);               % clamp within [1, N]   
                end

                %—— Prediction (identity dynamics) ——
                P_pred = uncertainty_Map(d,p(1), p(2)); 

                %—— Kalman gain —— 
                K = P_pred / (P_pred + R); % Cause the variance is small the value is close to 1 so the prediction has a strong value in the estimation

                %—— Update ——
                x_prior         = stateMap(d,p(1), p(2)); % At beginning all 0 so new believe is strong, with every new measurment the value oscillates always less 
                stateMap(d,p(1), p(2))   = x_prior + K*(z - x_prior);
                uncertainty_Map(d,p(1), p(2))     = (1 - K)*P_pred; % Believe on each cell, the closer to 0 the higher is the belief of what was seen
                localIdMap(d, p(1), p(2)) = idMap(i, j);

            end
        end
        
        R_map_evolution(d,step) = R;

        % Rotation of the position
        p = Bpos(d,:);
        tp = dronePos(d,:);
        if true_angle(d) ~= 0
            p(1) = Bpos(d,2);
            p(2) = Bpos(d,1);
            tp(1) = dronePos(d,2);
            tp(2) = dronePos(d,1);
            center = [(N+1)/2, (N+1)/2];   
            p_rot = rotatePointAroundCenter(p, center, true_angle(d)); 
            tp_rot = rotatePointAroundCenter(tp, center, true_angle(d));
            p = max(min(p_rot, N), 1);     
            tp = max(min(tp_rot, N), 1);
            p1 = p(1);
            p(1) = p(2);
            p(2) = p1;
            tp1 = tp(1);
            tp(1) = tp(2);
            tp(2) = tp1;
        end


        % Estimation of the relative orientation through Kabsh algorithm
        % and rotation of the map in the obtained angle
        for c = 1:3
            if d == 1 && c == 2 && norm(dronePos(d,:) - dronePos(c,:)) < connectionRange && ok(1)== 0
                [theta_deg(1), localIdMap(c,:,:), stateMap(c,:, :), uncertainty_Map(c,:, :), ok(1), ids] =...
                    estimateOrientationFromIDs(squeeze(localIdMap(d,:,:)), squeeze(localIdMap(c,:,:)), squeeze(stateMap(c,:, :)),...
                    squeeze(uncertainty_Map(c,:, :)), N, 'minMatches', 3, 'refineDeg', 1);
                if ok(1) 
                    fprintf('Rotation needed to rotate map 2 to match map 1 in CW direction = %d deg\n',theta_deg(1));
                    true_angle(2) = mod(abs(theta_deg(1) + true_angle(2)),360)*sign(theta_deg(1) + true_angle(2));    
                end
            end
            if d == 2 && c == 3 && norm(dronePos(d,:) - dronePos(c,:)) < connectionRange  
                
                if ok(3)== true && ok23(1) == false
                    [theta_deg(2), localIdMap(d,:,:), stateMap(d,:, :),uncertainty_Map(d,:, :), ok(2), ids] =...
                        estimateOrientationFromIDs(squeeze(localIdMap(c,:,:)), squeeze(localIdMap(d,:,:)),...
                        squeeze(stateMap(d,:, :)),squeeze(uncertainty_Map(d,:, :)), N, 'minMatches', 3, 'refineDeg', 1);
                    if ok(2)
                        fprintf('Rotation needed to rotate map 2 to match map 3 (equal to 1) in CW direction = %d deg\n',theta_deg(2));
                        ok23(1) = true; 
                        true_angle(2) = mod(abs(theta_deg(2) + true_angle(2)),360)*sign(theta_deg(2) + true_angle(2));
                    end
                elseif ok(1) == true && ok23(2) == false
                    [theta_deg(2), localIdMap(c,:,:), stateMap(c,:, :), uncertainty_Map(c,:, :), ok(2), ids] = ...
                    estimateOrientationFromIDs(squeeze(localIdMap(d,:,:)), squeeze(localIdMap(c,:,:)),...
                    squeeze(stateMap(c,:, :)),squeeze(uncertainty_Map(c,:, :)), N, 'minMatches', 3, 'refineDeg', 1);

                    if ok(2)
                        fprintf('Rotation needed to rotate map 3 to match map 2 (equal to 1) in CW direction = %d deg\n',theta_deg(2));
                        true_angle(3) = mod(abs(theta_deg(2) + true_angle(3)),360)*sign(theta_deg(2) + true_angle(3));
                        ok23(2) = true;
                    end
                elseif ok32 == false && ok23(2) == false && ok23(1) == false
                    [theta_deg(2), localIdMap(c,:,:), stateMap(c,:, :), uncertainty_Map(c,:, :), ok(2), ids] = ...
                    estimateOrientationFromIDs(squeeze(localIdMap(d,:,:)), squeeze(localIdMap(c,:,:)),...
                    squeeze(stateMap(c,:, :)),squeeze(uncertainty_Map(c,:, :)), N, 'minMatches', 3, 'refineDeg', 1);
                    
                    if ok(2)
                        fprintf('Rotation needed to rotate map 3 to match map 2 in CW direction = %d deg\n',theta_deg(2));
                        true_angle(3) = mod(abs(theta_deg(2) + true_angle(3)),360)*sign(theta_deg(2) + true_angle(3));
                        ok32 = true;
                    end

                end
            end
            if d == 1 && c == 3 && norm(dronePos(d,:) - dronePos(c,:)) < connectionRange && ok(3)== 0
                [theta_deg(3), localIdMap(c,:,:), stateMap(c,:, :),uncertainty_Map(c,:, :), ok(3), ids] =...
                    estimateOrientationFromIDs(squeeze(localIdMap(d,:,:)), squeeze(localIdMap(c,:,:)),...
                    squeeze(stateMap(c,:, :)),squeeze(uncertainty_Map(c,:, :)), N, 'minMatches', 3, 'refineDeg', 1);
                if ok(3)== true 
                    fprintf('Rotation needed to rotate map 3 to match map 1 in CW direction = %d deg\n',theta_deg(3));
                end
                if theta_deg(3) ~= 0
                    true_angle(3) = mod(abs(theta_deg(3) + true_angle(3)),360)*sign(theta_deg(3) + true_angle(3)); 
                end
            end
        end

        % Calculate which drones are enough close to comunicate their
        % position, map, and matrix covariances P
        D = size(dronePos, 1);
        distMatrix = squareform(pdist(dronePos));  % pairwise Euclidean distances
        connected = distMatrix < connectionRange;
        connected = connected - diag(diag(connected)); % remove self-connections
        
        % If the drones did not find relative orientation they cannot share
        % the maps or else
        if ok(1) == 0
            connected(1,2) = 0;
            connected(2,1) = 0;
        end
        if ok(2) == 0 || (ok23(1) == 0 && ok(3) == 1) || (ok(1) == 1 && ok23(2) == 0) %ok(2) == 0 || (ok(3) ~= ok(1) )
            connected(2,3) = 0;
            connected(3,2) = 0;
        end
        if ok(3) == 0
            connected(1,3) = 0;
            connected(3,1) = 0;
        end

        for i = 1:D
            neighbors{i} = find(connected(i,:));  % indices of drones connected to i
        end
        
        if AtVictim == 0 % Use Covariance intersection method untill all drones wont separate anymore
        [Bpos,P] = useDroneCPos(d,Bpos,dronePos,sigma_radar,P,neighbors,viewRadius);
        end

        % Join maps usign Metropolis Hastings method if all variances are
        % equal, or a row stochastic matrix to give more weight to the more
        % precise drones
        [stateMap, uncertainty_Map,localIdMap] = MH_map_fusion2(d, neighbors, stateMap, uncertainty_Map, sigma_velocity,sigma_radar,P0, localIdMap, theta_deg);
        
        % Central Fusion algorithm so the drones account for the 
        % correlation in the estimates and all drones benefit from a new measuremnt
        if AtVictim == 1 
            [P,xk,p] = CentralFusionCL(d, xk, P, dronePos, sigma_radar, neighbors,viewRadius);
        % Rotation of the position
            if true_angle(d) ~= 0
                tmp = p(1);
                p(1) = p(2);
                p(2) = tmp;
                center = [(N+1)/2, (N+1)/2];   
                p_rot = rotatePointAroundCenter(p', center, true_angle(d)); 
                p = max(min(p_rot, N), 1);     
                p1 = p(1);
                p(1) = p(2);
                p(2) = p1;
            end
        end

        if visualize_in_real_time == 1
            % Update local full true map
            % Update all drones’ maps & uncertainty

            % update local-maps images
            set( hImg(d), 'CData', squeeze(stateMap(d,:,:)) );

            % update uncertainty image
            set( hUnc(d), 'CData', squeeze(uncertainty_Map(d,:,:)) );
            %True-map figure
            set( hPoints(d), 'XData', dronePos(d,1),'YData', dronePos(d,2) );
            set( hPoints2(d), 'XData', tp(1),'YData', tp(2) );
            %believed drones position
            set( hPoint(d), 'XData', p(1),'YData', p(2) );

               % push the updates to the screen
            axis equal tight;
        end

       
        % Check if a drone found a cell which could be the victim, and if
        % the drone is secure more than 65% consider you found it
        A = squeeze(stateMap(d,:,:));
        [maxValue, linearIdx] = max(A(:));
        [rowM, colM] = ind2sub(size(A), linearIdx);
        if any(any(stateMap(d,rowM,colM,1) > 9)) && victimFound == false && uncertainty_Map(d,rowM,colM) < min_certainty

            A = squeeze(stateMap(d,:,:));
            [maxValue, linearIdx] = max(A(:));
            [rowVict, colVict] = ind2sub(size(A), linearIdx);
            p = [rowVict, colVict]; % Points rotation
            if true_angle(d) ~= 0
                center = [(N+1)/2, (N+1)/2];  
                p_rot = rotatePointAroundCenter([rowVict, colVict], center, -true_angle(d)); 
                p = max(min(p_rot, N), 1);               % clamp within [1, N]   
            end
            regrup_pos = [p(2) p(1)];

            fprintf('Drone %d found the victim at step %d!\n', d, step);
            victimFound = true;
            founder = d;
            finalStep = step;
        end
        % Uncertainty of each drone over the map and error between where
        % the drone believes it is and where actually is
        avgUncertaintyHistory(d, step) = mean(uncertainty_Map(d,:,:), 'all');
        Pos_error(:,step) = sqrt((dronePos(:,1)-Bpos(:,1)).^2+(dronePos(:,2)-Bpos(:,2)).^2);
        set(hErr(d),   'XData',1:step, 'YData', Pos_error(d,1:step));


    end

    drawnow;
    p=p+1;
    if finish 
        break; 
    end
end

avgUncertaintyHistory = avgUncertaintyHistory(:, 1:step-1);

%% Drone Figures

figure
drone_state_map = squeeze(stateMap(founder,:,:));
imagesc(drone_state_map)
title('Drone map')
axis equal tight;
colorbar;
clim([0 5]);
set(gca, 'YDir', 'normal');
exportgraphics(gcf,'immagini/9_Drone_map.pdf','ContentType','vector')

simt = linspace(1,step,step);
figure
sgtitle('Measurement noise covariance for the map recognition')
plot(simt,R_map_evolution(1,1:step),simt,R_map_evolution(2,1:step),simt,R_map_evolution(3,1:step))
legend('Drone 1','Drone 2', 'Drone 3')
xlim([0 step])
xlabel('time step')
ylabel('R_map value')
exportgraphics(gcf,'immagini/10_Measurement_noise_covariance.pdf','ContentType','vector')

figure
sgtitle('Position error over time')
plot(simt,Pos_error(1,1:step),simt,Pos_error(2,1:step),simt,Pos_error(3,1:step))
grid on;
grid minor
legend('Drone 1','Drone 2', 'Drone 3')
xlabel('time step k')
ylabel('position error [m]')
xlim([0 step])
exportgraphics(gcf,'immagini/11_Position_error_over_time.pdf','ContentType','vector')

map_error = zeros(N,N);
mean_total_map_error = 0;
known_points = 0;

%% Map refinement to obtain a more cleaner image

rounded_state_map = round(squeeze(stateMap(founder,:,:)));

% Assume rounded_state_map is NxN and uncertainty_Map has same size.
% Consider only the explorated zones of the map and eliminate isolated
% pixels which are probably errors in the drone sonar/camera
for ref = 1:4
    for i = 2:N-1
        for j = 2:N-1
            if uncertainty_Map(founder,i,j) < 1
                % Get 4-neighborhood values
                up    = rounded_state_map(i-1,j);
                down  = rounded_state_map(i+1,j);
                left  = rounded_state_map(i,j-1);
                right = rounded_state_map(i,j+1);
    
                % Rule 1: If vertical neighbors match AND horizontal neighbors match
                if (up == down) && (left == right)
                    rounded_state_map(i,j) = up;
                end
    
                % Rule 2: If all 4 neighbors are zero, force to zero
                if (up == 0) && (down == 0) && (left == 0) && (right == 0)
                    rounded_state_map(i,j) = 0;
                end
            end
        end
    end
end

% Apply median filter to smooth isolated noise
rounded_state_map = medfilt2(rounded_state_map, [3 3]);

% Remove isolated non-zero pixels surrounded by zeros
mask = (rounded_state_map == 0);
rounded_state_map(~mask & imerode(mask, ones(3))) = 0;
rounded_state_map(rowVict,colVict) = 7;

figure
imagesc(rounded_state_map)
axis equal tight; 
title('Refined round map')
colorbar;
clim([0 5]);
set(gca, 'YDir', 'normal');
for i=1:N
    for j=1:N
        if uncertainty_Map(founder,i,j)<0.5
            map_error(i,j) = abs(typeMap(i,j)-rounded_state_map(i,j));
            mean_total_map_error = mean_total_map_error + abs(typeMap(i,j)-rounded_state_map(i,j));
            known_points = known_points + 1;
        end
    end
end
exportgraphics(gcf,'immagini/12_rounded_state_map.pdf','ContentType','vector')
mean_total_map_error = mean_total_map_error/known_points*100;
fprintf('The error of the created map is of %.2f%%\n',mean_total_map_error);

figure
imagesc(map_error)
title('Absolute map error')
axis equal tight;
colorbar;
clim([0 5]);
set(gca, 'YDir', 'normal');
exportgraphics(gcf,'immagini/13_Absolute_map_error.pdf','ContentType','vector')
% How much each drone didn't knew about the map in time
figure;
plot(avgUncertaintyHistory');
xlabel('Step');
ylabel('Average Uncertainty');
legend('Drone 1', 'Drone 2', 'Drone 3');
title('Uncertainty Reduction Over Time');
grid on;
exportgraphics(gcf,'immagini/14_Uncertainty_Reduction_Over_Time.pdf','ContentType','vector')

%% Safety Map Creation with Buffer for Boat
fprintf('\nSAFETY MAP CREATION WITH BUFFER \n');
safetyDistance = 10;
victimSafetyDistance = 25;
goal = [victimRow, victimCol];

safetyMap = crea_safety_map_typeMap(rounded_state_map, boatPos, victimPos, safetyDistance, victimSafetyDistance);
safetyMap2 = crea_safety_map_typeMap(typeMap, idMap_boat, victimPos, safetyDistance, victimSafetyDistance);

%% Path Calculation with A*
fprintf('\nPATH CALCULATION WITH A* \n');
[pathRows, pathCols, success] = improved_astar_with_safety(safetyMap, start, goal);
if ~success
    fprintf('First attempt failed, trying with normal complex map...\n');
    [pathRows, pathCols, success] = improved_astar_with_safety(safetyMap2, start, goal);
end

%% Final Results Visualization
visualizza_risultati_finali(rounded_state_map, victimPos, boatPos, pathRows, pathCols, success);
exportgraphics(fig1,'immagini/4_local_map.pdf','ContentType','vector')
exportgraphics(fig2,'immagini/5_uncertainty_map1.pdf','ContentType','vector')
exportgraphics(figErr,'immagini/7_position_error.pdf','ContentType','vector')

%% Summary
fprintf('\nSUMMARY \n');
stampa_riepilogo(boatPos, victimPos, pathRows, pathCols, costMap, boatRow, boatCol);

fprintf('\nSIMULATION COMPLETED !!!\n');

